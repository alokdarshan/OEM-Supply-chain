"""Orchestrator: wires ingestion -> alerts and runs the full planning cycle (SDD 4.2 data flow)."""
import datetime as dt
import json

import numpy as np
import pandas as pd

from . import alerts as al, data, inventory, ml_sensing, procurement, reconciliation, tier2, volatility
from .config import load_config
from .db import DB, utcnow
from .events import EventBus
from .ingestion import ingest_records, week_start


class ADSPS:
    def __init__(self, db_path=":memory:"):
        self.db = DB(db_path)
        self.bus = EventBus()
        self.bus.subscribe("ingestion_complete", self._on_ingest)
        self.cache = {}

    @property
    def cfg(self):
        return load_config(self.db)

    # -- ingestion + immediate exception detection (FR-5.1)
    def _on_ingest(self, s):
        self.last_alerts = al.evaluate_ingestion(self.db, self.cfg, s["first_id"], s["last_id"])

    def ingest(self, records, source="api", actor="system"):
        self.last_alerts = []
        s = ingest_records(self.db, records, source, actor, bus=self.bus)
        s["alerts_raised"] = len(self.last_alerts)
        return s

    # -- full planning cycle
    def run_cycle(self, as_of=None, force_ml_retrain=False):
        as_of = as_of or dt.date.today()
        cfg, db = self.cfg, self.db
        latest = data.latest_versions(db, as_of)
        if latest.empty:
            raise RuntimeError("no forecasts ingested")
        wide, actuals = data.to_wide(latest), data.load_actuals(db)
        sku_cost = db.df("SELECT sku_id, unit_cost FROM sku").set_index("sku_id")["unit_cost"]

        trans, skum = volatility.compute(wide, actuals, cfg, as_of, sku_cost)
        db.replace_table("transition_metrics", trans[["sku_id", "transition", "mape", "bias", "n"]])
        db.replace_table("sku_metrics", skum[["sku_id", "vi", "volume", "mix", "swing", "bullwhip", "abc_class"]])
        vi, mix = skum.set_index("sku_id")["vi"], skum.set_index("sku_id")["mix"]

        ml_info = ml_sensing.retrain_if_needed(db, wide, actuals, mix, cfg, as_of, force=force_ml_retrain) \
            if cfg["ml"]["enabled"] else {}
        ml = ml_sensing.predict(db, wide, actuals, mix, cfg, as_of)
        recon = reconciliation.reconcile(wide, as_of, cfg, vi, ml)
        db.replace_table("reconciled_plan", recon.assign(period=recon["period"].astype(str))[
            ["sku_id", "period", "reconciled", "sigma", "lo", "hi", "rule_qty", "ml_qty", "ml_weight", "ml_note"]])

        recs, states, conf = procurement.run(db, cfg, recon, skum, as_of)
        db.execute("UPDATE recommendation SET status='SUPERSEDED' WHERE status='DRAFT'")
        if len(recs):
            cols = list(recs.columns)
            db.executemany(f"INSERT INTO recommendation({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
                           recs.astype(object).where(recs.notna(), None).values.tolist())
        db.replace_table("item_state", states)
        db.execute("DELETE FROM po_conflict")
        if len(conf):
            db.executemany("""INSERT INTO po_conflict(run_date,po_id,item_id,conflict_type,suggestion,qty_affected)
                VALUES(?,?,?,?,?,?)""", conf[["run_date", "po_id", "item_id", "conflict_type", "suggestion",
                                              "qty_affected"]].values.tolist())
        n_po_alerts = al.raise_po_conflict_alerts(db, cfg, conf)

        health = inventory.health(db, cfg, states, skum, recon, as_of) if len(states) else {}
        sent = tier2.share_requirement_deltas(db, cfg, recon, as_of=as_of)
        summary = self._summary(as_of, cfg, skum, recon, states, recs, conf, health, ml_info)
        db.execute("INSERT INTO kpi_snapshot(as_of,payload) VALUES(?,?)", (as_of.isoformat(), json.dumps(summary, default=float)))
        db.audit("system", "planning_cycle", as_of.isoformat(), {"recs": len(recs), "po_alerts": n_po_alerts})
        self.cache = {"recon": recon, "skum": skum, "states": states}
        return summary | {"tier2_messages_sent": len(sent)}

    # -- executive KPIs (FR-7.2)
    def _summary(self, as_of, cfg, skum, recon, states, recs, conf, health, ml_info):
        db = self.db
        wc = health.get("working_capital", {})
        plants = recon.groupby(["plant_id", "period"])["reconciled"].sum().reset_index()
        swing = {p: float(g["reconciled"].std() / g["reconciled"].mean()) if g["reconciled"].mean() else 0.0
                 for p, g in plants.groupby("plant_id")}
        at_risk = states[states["short_units"] > 0] if len(states) else states
        models = ml_sensing.model_report(db)
        return {
            "as_of": as_of.isoformat(),
            "working_capital": wc,
            "stock_out_risk": {"items_at_risk": int(len(at_risk)),
                               "shortage_value": float(at_risk["short_value"].sum()) if len(at_risk) else 0.0,
                               "top_items": at_risk.nlargest(5, "short_value")[["item_id", "short_units", "short_value"]]
                               .to_dict("records") if len(at_risk) else []},
            "capacity_swing_cv_by_plant": swing,
            "logistics_premium_exposure": wc.get("expedite_premium_exposure", 0.0),
            "volatility": {"mean_vi": float(skum["vi"].mean()), "high_vi_skus": int((skum["vi"] > 0.6).sum()),
                           "mean_bullwhip": float(skum["bullwhip"].mean())},
            "inventory_ratio": health.get("ratio", {}),
            "inventory_families": health.get("families", []),
            "obsolescence_top": health.get("obsolescence", [])[:8],
            "recommendations": {"order_now": int((recs["action"] == "ORDER_NOW").sum()) if len(recs) else 0,
                                "planned": int((recs["action"] == "PLANNED_ORDER").sum()) if len(recs) else 0,
                                "po_conflicts": int(len(conf))},
            "open_alerts": len(al.list_alerts(db, "open")),
            "ml_models": models,
        }

    def latest_summary(self):
        r = self.db.query("SELECT payload FROM kpi_snapshot ORDER BY id DESC LIMIT 1")
        return json.loads(r[0]["payload"]) if r else {}


def export_report(db, path):
    """Excel export of key outputs (FR-7.3)."""
    with pd.ExcelWriter(path) as xw:
        for name, sql in [("Recommendations", "SELECT * FROM recommendation WHERE status IN ('DRAFT','ACCEPTED','OVERRIDDEN')"),
                          ("ItemState", "SELECT * FROM item_state"), ("Alerts", "SELECT * FROM alert"),
                          ("POConflicts", "SELECT * FROM po_conflict"), ("SKUVolatility", "SELECT * FROM sku_metrics"),
                          ("ForecastAccuracy", "SELECT * FROM transition_metrics")]:
            db.df(sql).to_excel(xw, sheet_name=name, index=False)
    return path

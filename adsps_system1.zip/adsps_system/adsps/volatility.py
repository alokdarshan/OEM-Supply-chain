"""Volatility & Bullwhip Analytics Engine (SDD 3.4; SRS FR-2.x)."""
import datetime as dt
import math

import numpy as np
import pandas as pd

from .ingestion import week_start

TRANS = [("ABP", "QRF"), ("QRF", "MFU"), ("MFU", "WDPA")]


def _with_actuals(wide, actuals):
    w = wide.reset_index()
    if len(actuals):
        w = w.merge(actuals.rename("actual").reset_index(), on=["sku_id", "period"], how="left")
    else:
        w["actual"] = np.nan
    w["final"] = w["actual"].fillna(w["WDPA"]).fillna(w["MFU"]).fillna(w["QRF"]).fillna(w["ABP"])
    return w


def compute(wide, actuals, cfg, as_of, sku_cost=None):
    """Returns (transitions, sku_metrics).
    transitions: MAPE & bias per SKU per horizon transition (later horizon treated as 'actual').
    sku_metrics: volatility index + components, bullwhip amplification, ABC class."""
    cur = week_start(as_of)
    start = cur - dt.timedelta(weeks=cfg["history_window_weeks"])
    w = _with_actuals(wide, actuals)
    w = w[w["period"] >= start]

    rows = []
    for a, b in TRANS + [("WDPA", "actual")]:
        sub = w.dropna(subset=[a, b])
        sub = sub[sub[b] > 0]
        if sub.empty:
            continue
        g = pd.DataFrame({"sku_id": sub["sku_id"], "ape": (sub[b] - sub[a]).abs() / sub[b], "bias": sub[a] - sub[b]})
        r = g.groupby("sku_id").agg(mape=("ape", "mean"), bias=("bias", "mean"), n=("ape", "size")).reset_index()
        r["transition"] = f"{a}->{'ACT' if b == 'actual' else b}"
        rows.append(r)
    trans = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(
        columns=["sku_id", "mape", "bias", "n", "transition"])

    skus = pd.Index(w["sku_id"].unique(), name="sku_id")
    vol = trans[~trans["transition"].str.endswith("ACT")].groupby("sku_id")["mape"].mean().reindex(skus).fillna(0.0)

    # mix shift: change of a SKU's share inside its plant between ABP and the latest view
    m = w.dropna(subset=["ABP", "final"])
    m = m[(m["ABP"] > 0) & (m["final"] > 0)].copy()
    if len(m):
        m["sA"] = m["ABP"] / m.groupby(["plant_id", "period"])["ABP"].transform("sum")
        m["sL"] = m["final"] / m.groupby(["plant_id", "period"])["final"].transform("sum")
        m["rel"] = (m["sA"] - m["sL"]).abs() / m["sL"]
        mix = m.groupby("sku_id")["rel"].mean().reindex(skus).fillna(0.0)
    else:
        mix = pd.Series(0.0, index=skus)

    # week-over-week swing of the best-available demand series
    hist = w[w["period"] <= cur].sort_values(["sku_id", "period"])
    sw = hist.groupby("sku_id")["final"].apply(lambda s: s.pct_change().replace([np.inf, -np.inf], np.nan).abs().mean())
    swing = sw.reindex(skus).fillna(0.0)

    sc, wt = cfg["vi_scales"], cfg["vi_weights"]
    comp = pd.DataFrame({"volume": (vol / sc["volume"]).clip(0, 1), "mix": (mix / sc["mix"]).clip(0, 1),
                         "swing": (swing / sc["swing"]).clip(0, 1)})
    vi = sum(comp[k] * wt[k] for k in wt) / sum(wt.values())

    # bullwhip: CV(realised demand) / CV(OEM annual plan) over the same periods
    def cv(s):
        s = s.dropna()
        return s.std() / s.mean() if len(s) > 3 and s.mean() > 0 else np.nan
    bw = {}
    for sku, g in hist.groupby("sku_id"):
        g = g.dropna(subset=["ABP", "final"])
        c0, c1 = cv(g["ABP"]), cv(g["final"])
        bw[sku] = c1 / c0 if c0 and c0 > 0 and not np.isnan(c1) else 1.0

    out = comp.copy()
    out["vi"] = vi
    out["bullwhip"] = pd.Series(bw).reindex(skus).fillna(1.0).clip(0, 10)
    # ABC class by annual consumption value
    avg = hist.groupby("sku_id")["final"].mean().reindex(skus).fillna(0)
    cost = (sku_cost.reindex(skus).fillna(1.0) if sku_cost is not None else 1.0)
    val = (avg * cost).sort_values(ascending=False)
    share = val.cumsum() / max(val.sum(), 1e-9)
    cls = pd.Series(np.where(share <= 0.70, "A", np.where(share <= 0.90, "B", "C")), index=val.index)
    cls.iloc[0:1] = "A"
    out["abc_class"] = cls.reindex(skus)
    return trans, out.reset_index()


def lot_sized_orders(requirements, moq):
    """Tier-1 -> Tier-2 order stream when the supplier's MOQ forces lumpy orders."""
    carry, orders = 0.0, []
    for r in requirements:
        need = r - carry
        q = math.ceil(need / moq) * moq if need > 0 else 0.0
        carry = carry + q - r
        orders.append(q)
    return orders


def amplification_ratio(upstream, downstream):
    """Bullwhip ratio = Var(downstream)/Var(upstream)  (>1 means variability is amplified)."""
    u, d = np.var(upstream, ddof=1), np.var(downstream, ddof=1)
    return float(d / u) if u > 0 else float("nan")

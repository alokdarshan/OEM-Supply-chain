"""Tiny in-process event bus (stand-in for Kafka / managed queue in the SDD)."""
from collections import defaultdict


class EventBus:
    def __init__(self):
        self._subs = defaultdict(list)

    def subscribe(self, topic, fn):
        self._subs[topic].append(fn)

    def publish(self, topic, payload=None):
        for fn in self._subs[topic]:
            fn(payload)

"""API / Application layer (SDD 5): REST + RBAC (API keys) + minimal role-based web UI."""
import hashlib
import json
import os

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from . import alerts as al, ingestion, procurement, tier2
from .config import save_config
from .platform import ADSPS

ROLES = {"admin", "demand_planner", "procurement", "plant_manager", "executive", "tier2"}


def _h(k):
    return hashlib.sha256(k.encode()).hexdigest()


def add_user(db, user_id, role, key, supplier_id=None):
    db.execute("INSERT OR REPLACE INTO users(user_id,role,supplier_id,key_hash) VALUES(?,?,?,?)",
               (user_id, role, supplier_id, _h(key)))


class Record(BaseModel):
    oem_id: str
    variant_code: str
    horizon_type: str
    forecast_date: str
    effective_period: str
    quantity: float
    plant_id: str | None = None


class IngestBody(BaseModel):
    source: str = "api"
    records: list[Record]


class Decision(BaseModel):
    decision: str
    reason: str | None = None
    final_qty: float | None = None


class Resolve(BaseModel):
    notes: str


class Commit(BaseModel):
    status: str
    commit_qty: float | None = None
    commit_date: str | None = None


def create_app(system: ADSPS) -> FastAPI:
    app = FastAPI(title="ADSPS", version="1.0.0")
    db = system.db

    def auth(*allowed):
        def dep(x_api_key: str = Header(default="")):
            u = db.query("SELECT * FROM users WHERE key_hash=?", (_h(x_api_key),))
            if not u:
                raise HTTPException(401, "invalid API key")
            u = u[0]
            if "admin" != u["role"] and u["role"] not in allowed:
                raise HTTPException(403, f"role {u['role']} not permitted")
            return u
        return dep

    INTERNAL = ("demand_planner", "procurement", "plant_manager", "executive")

    @app.post("/api/v1/forecasts/ingest")
    def ingest(body: IngestBody, u=Depends(auth("demand_planner"))):
        return system.ingest([r.model_dump() for r in body.records], body.source, u["user_id"])

    @app.post("/api/v1/planning/run")
    def run(u=Depends(auth("demand_planner", "procurement"))):
        return system.run_cycle()

    @app.get("/api/v1/skus/{sku_id}/volatility")
    def volatility(sku_id: str, u=Depends(auth(*INTERNAL))):
        m = db.query("SELECT * FROM sku_metrics WHERE sku_id=?", (sku_id,))
        if not m:
            raise HTTPException(404, "sku not found")
        return {"metrics": m[0], "transitions": db.query("SELECT * FROM transition_metrics WHERE sku_id=?", (sku_id,))}

    @app.get("/api/v1/skus/{sku_id}/plan")
    def plan(sku_id: str, u=Depends(auth(*INTERNAL))):
        return db.query("SELECT * FROM reconciled_plan WHERE sku_id=? ORDER BY period", (sku_id,))

    @app.get("/api/v1/skus/{sku_id}/recommendation")
    def sku_rec(sku_id: str, u=Depends(auth("demand_planner", "procurement", "executive"))):
        rows = db.query("""SELECT r.* FROM recommendation r JOIN bom_item b ON b.item_id=r.item_id
                           WHERE b.sku_id=? AND r.status='DRAFT'""", (sku_id,))
        for r in rows:
            r["explain"], r["alternatives"] = json.loads(r.pop("explain_json")), json.loads(r.pop("alt_json"))
        return rows

    @app.get("/api/v1/recommendations")
    def recs(status: str = "DRAFT", action: str | None = None, u=Depends(auth("procurement", "demand_planner", "executive"))):
        sql, p = "SELECT rec_id,item_id,action,recommended_qty,recommended_date,risk_posture,status FROM recommendation WHERE status=?", [status]
        if action:
            sql += " AND action=?"; p.append(action)
        return db.query(sql + " ORDER BY rec_id LIMIT 500", p)

    @app.post("/api/v1/recommendations/{rec_id}/decision")
    def decision(rec_id: int, body: Decision, u=Depends(auth("procurement", "demand_planner"))):
        try:
            return procurement.decide(db, rec_id, body.decision, u["user_id"], body.reason, body.final_qty)
        except KeyError as e:
            raise HTTPException(404, str(e))
        except ValueError as e:
            raise HTTPException(422, str(e))

    @app.get("/api/v1/alerts")
    def alerts(status: str = "open", u=Depends(auth(*INTERNAL))):
        return al.list_alerts(db, status, u["role"])

    @app.post("/api/v1/alerts/{alert_id}/resolve")
    def resolve(alert_id: int, body: Resolve, u=Depends(auth(*INTERNAL))):
        try:
            al.resolve(db, alert_id, body.notes, u["user_id"])
        except KeyError as e:
            raise HTTPException(404, str(e))
        except ValueError as e:
            raise HTTPException(422, str(e))
        return {"status": "resolved"}

    @app.get("/api/v1/dashboards/executive-summary")
    def exec_summary(u=Depends(auth("executive"))):
        return system.latest_summary()

    @app.get("/api/v1/dashboards/executive-detail")
    def exec_detail(u=Depends(auth("executive"))):
        import math
        plan = db.query("SELECT period, SUM(reconciled) r, SUM(sigma*sigma) v FROM reconciled_plan GROUP BY period ORDER BY period")
        demand = [{"period": x["period"], "demand": x["r"], "lo": max(0, x["r"] - 1.2816 * math.sqrt(x["v"])),
                   "hi": x["r"] + 1.2816 * math.sqrt(x["v"])} for x in plan]
        vis = [m["vi"] for m in db.query("SELECT vi FROM sku_metrics")]
        hist = [sum(1 for v in vis if b / 5 <= v < (b + 1) / 5 or (b == 4 and v >= 1)) for b in range(5)]
        return {
            "demand_outlook": demand,
            "accuracy": db.query("SELECT transition, AVG(mape) mape, AVG(bias) bias FROM transition_metrics GROUP BY transition"),
            "vi_histogram": {"bins": ["0-0.2", "0.2-0.4", "0.4-0.6", "0.6-0.8", "0.8-1.0"], "counts": hist},
            "alerts_by_type": db.query("SELECT type, severity, COUNT(*) n FROM alert WHERE status='open' GROUP BY type, severity"),
            "sla_breaches": len(al.sla_breaches(db)),
            "po_conflicts": db.query("SELECT conflict_type, COUNT(*) n, SUM(qty_affected) qty FROM po_conflict GROUP BY conflict_type"),
            "top_excess": db.query("SELECT item_id, excess_units, excess_value, weeks_cover FROM item_state ORDER BY excess_value DESC LIMIT 8"),
            "top_shortage": db.query("SELECT item_id, short_units, short_value, weeks_cover FROM item_state ORDER BY short_value DESC LIMIT 8"),
            "top_volatile_skus": db.query("SELECT sku_id, vi, volume, mix, swing, bullwhip, abc_class FROM sku_metrics ORDER BY vi DESC LIMIT 10"),
            "decisions": db.query("SELECT status, COUNT(*) n FROM recommendation WHERE status IN ('DRAFT','ACCEPTED','OVERRIDDEN') GROUP BY status"),
        }

    @app.get("/executive", response_class=HTMLResponse)
    def exec_ui():
        return open(os.path.join(os.path.dirname(__file__), "executive.html"), encoding="utf-8").read()

    @app.get("/api/v1/inventory/health")
    def inv_health(u=Depends(auth("executive", "procurement"))):
        return {"item_state": db.query("SELECT * FROM item_state ORDER BY excess_value DESC LIMIT 50"),
                "po_conflicts": db.query("SELECT * FROM po_conflict")}

    @app.get("/api/v1/tier2/requirements")
    def t2_reqs(u=Depends(auth("tier2"))):                       # Tier-2 sees only own messages
        sid = u["supplier_id"]
        return db.query("SELECT * FROM outbox WHERE supplier_id=? ORDER BY msg_id DESC", (sid,))

    @app.post("/api/v1/tier2/requirements/{msg_id}/commit")
    def t2_commit(msg_id: int, body: Commit, u=Depends(auth("tier2"))):
        try:
            tier2.record_commitment(db, msg_id, u["supplier_id"], body.status, body.commit_qty, body.commit_date)
        except PermissionError as e:
            raise HTTPException(403, str(e))
        except ValueError as e:
            raise HTTPException(422, str(e))
        return {"status": "recorded"}

    @app.get("/api/v1/admin/config")
    def get_cfg(u=Depends(auth())):
        return system.cfg

    @app.put("/api/v1/admin/config")
    def put_cfg(patch: dict, u=Depends(auth())):
        return save_config(db, patch, u["user_id"])

    @app.get("/", response_class=HTMLResponse)
    def ui():
        return open(os.path.join(os.path.dirname(__file__), "ui.html"), encoding="utf-8").read()

    return app

"""Point-in-time data access helpers shared by the engines."""
import datetime as dt

import pandas as pd

from .ingestion import HORIZONS, week_start


def latest_versions(db, as_of):
    """Latest ForecastVersion per (sku, period, horizon) known on `as_of` (point-in-time)."""
    df = db.df("""SELECT forecast_id, sku_id, oem_id, plant_id, effective_period period, horizon_type horizon,
                  quantity qty, forecast_date FROM forecast_version WHERE forecast_date<=?""", (as_of.isoformat(),))
    if df.empty:
        return df
    df = df.sort_values(["forecast_date", "forecast_id"]).drop_duplicates(["sku_id", "period", "horizon"], keep="last")
    df["period"] = pd.to_datetime(df["period"]).dt.date
    return df


def to_wide(latest):
    """-> DataFrame indexed (sku_id, period) with columns ABP,QRF,MFU,WDPA (+oem_id, plant_id)."""
    if latest.empty:
        return pd.DataFrame(columns=["oem_id", "plant_id", *HORIZONS])
    w = latest.pivot(index=["sku_id", "period"], columns="horizon", values="qty")
    for h in HORIZONS:
        if h not in w:
            w[h] = float("nan")
    w = w[list(HORIZONS)]
    meta = latest.drop_duplicates("sku_id").set_index("sku_id")[["oem_id", "plant_id"]]
    w = w.join(meta, on="sku_id")
    return w


def load_actuals(db):
    a = db.df("SELECT sku_id, period, quantity actual FROM actual")
    if not a.empty:
        a["period"] = pd.to_datetime(a["period"]).dt.date
    return a.set_index(["sku_id", "period"])["actual"] if not a.empty else pd.Series(dtype=float, name="actual")


def current_week(as_of):
    return week_start(as_of)


def weeks(start, n):
    return [start + dt.timedelta(weeks=i) for i in range(n)]

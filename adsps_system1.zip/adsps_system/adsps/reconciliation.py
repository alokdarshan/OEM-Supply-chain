"""Demand Sensing & Reconciliation Engine (SDD 3.2; SRS FR-3.1).
Blends ABP/QRF/MFU/WDPA into one working plan per SKU/period with a volatility-driven uncertainty band."""
import numpy as np
import pandas as pd

from .ingestion import HORIZONS, week_start

Z80 = 1.2816  # 80% two-sided band


def horizon_weight_matrix(lead_days, cfg):
    tiers = sorted(cfg["horizon_weights"], key=lambda t: t["max_days"])
    W = np.zeros((len(lead_days), len(HORIZONS)))
    done = np.zeros(len(lead_days), bool)
    for t in tiers:
        sel = (lead_days <= t["max_days"]) & ~done
        W[sel] = [t["w"].get(h, 0.0) for h in HORIZONS]
        done |= sel
    return W


def reconcile(wide, as_of, cfg, vi, ml=None):
    """wide: (sku_id, period) x horizons; vi: Series sku->volatility index; ml: optional frame indexed
    (sku_id, period) with ml_qty, ml_lo, ml_hi, ml_weight, ml_note."""
    cur = week_start(as_of)
    w = wide.reset_index()
    w = w[w["period"] >= cur].reset_index(drop=True)
    lead = (pd.to_datetime(w["period"]) - pd.Timestamp(cur)).dt.days.clip(lower=0).to_numpy()
    vals = w[list(HORIZONS)].to_numpy(float)
    avail = ~np.isnan(vals)
    W = horizon_weight_matrix(lead, cfg) * avail
    zero = (W.sum(1) == 0) & avail.any(1)          # only horizons with zero weight exist -> use what we have
    W[zero] = avail[zero].astype(float)
    s = W.sum(1)
    ok = s > 0
    v0 = np.nan_to_num(vals)
    rule = np.where(ok, (W * v0).sum(1) / np.where(ok, s, 1), np.nan)
    spread = np.sqrt(np.where(ok, (W * (v0 - rule[:, None]) ** 2 * avail).sum(1) / np.where(ok, s, 1), 0))
    v = w["sku_id"].map(vi).fillna(0.3).to_numpy()
    sig_rel = cfg["base_cv"] + cfg["vol_k"] * v
    factor = 0.4 + 0.6 * np.minimum(lead / 90.0, 1.0)      # nearer periods are more certain
    sigma = np.sqrt(spread ** 2 + (rule * sig_rel * factor) ** 2)
    out = w[["sku_id", "period", "plant_id", "oem_id"]].copy()
    out["rule_qty"], out["sigma"], out["lead_days"] = rule, sigma, lead
    out["reconciled"] = rule
    out["ml_qty"], out["ml_weight"], out["ml_note"] = np.nan, 0.0, ""
    if ml is not None and len(ml):
        j = out.join(ml, on=["sku_id", "period"], rsuffix="_m")
        has = j["ml_qty_m"].notna()
        wgt = j["ml_weight_m"].fillna(0.0).to_numpy() * has.to_numpy()
        ml_sig = ((j["ml_hi"] - j["ml_lo"]) / (2 * Z80 )).fillna(0.0).to_numpy()
        out["ml_qty"] = j["ml_qty_m"]
        out["ml_weight"] = wgt
        out["ml_note"] = j["ml_note_m"].fillna("")
        out["reconciled"] = (1 - wgt) * rule + wgt * np.nan_to_num(j["ml_qty_m"].to_numpy(float))
        sigma = (1 - wgt) * sigma + wgt * ml_sig
        out["sigma"] = sigma
    out = out[ok].copy()
    out["lo"] = (out["reconciled"] - Z80 * out["sigma"]).clip(lower=0)
    out["hi"] = out["reconciled"] + Z80 * out["sigma"]
    return out.reset_index(drop=True)

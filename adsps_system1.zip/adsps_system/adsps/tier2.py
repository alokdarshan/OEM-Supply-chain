"""Tier-2 Collaboration Module (SDD 3.8; SRS FR-6.x) + notification gateway + ERP connector stubs."""
import csv
import datetime as dt
import json
import os

import pandas as pd

from .db import utcnow
from .ingestion import week_start


class OutboxGateway:
    """Stand-in for portal/email/EDI delivery: persists the message; swap for SMTP/EDI/SFTP in production."""
    def send(self, db, supplier_id, payload, channel="portal"):
        return db.execute("INSERT INTO outbox(supplier_id,channel,payload,created_at) VALUES(?,?,?,?)",
                          (supplier_id, channel, json.dumps(payload), utcnow())).lastrowid


def share_requirement_deltas(db, cfg, recon, gateway=None, as_of=None):
    """Publish near-term requirement changes (> threshold vs. last shared snapshot) to each affected Tier-2."""
    gateway = gateway or OutboxGateway()
    cur = week_start(as_of or dt.date.today())
    n = cfg["tier2"]["horizon_weeks"]
    pers = [cur + dt.timedelta(weeks=i) for i in range(n)]
    sup = db.df("SELECT item_id, supplier_id FROM supplier").drop_duplicates("item_id")
    bom = db.df("SELECT item_id, sku_id, qty_per_unit FROM bom_item")
    r = recon[recon["period"].isin(pers)][["sku_id", "period", "reconciled"]]
    j = bom.merge(r, on="sku_id")
    j["req"] = j["reconciled"] * j["qty_per_unit"]
    req = j.groupby(["item_id", "period"])["req"].sum().reset_index().merge(sup, on="item_id")
    snap = db.df("SELECT * FROM tier2_snapshot")
    snap["period"] = pd.to_datetime(snap["period"]).dt.date if len(snap) else snap.get("period")
    prev = {(s.supplier_id, s.item_id, s.period): s.qty for s in snap.itertuples()} if len(snap) else {}
    sent = []
    for sid, g in req.groupby("supplier_id"):
        deltas = []
        for x in g.itertuples():
            old = prev.get((sid, x.item_id, x.period))
            if old is None or (old > 0 and abs(x.req - old) / old >= cfg["tier2"]["share_threshold"]):
                deltas.append({"item_id": x.item_id, "period": x.period.isoformat(), "required_qty": round(x.req, 1),
                               "previous_qty": None if old is None else round(old, 1)})
        if deltas:
            sent.append(gateway.send(db, sid, {"type": "requirement_update", "deltas": deltas}))
    db.executemany("""INSERT INTO tier2_snapshot(supplier_id,item_id,period,qty) VALUES(?,?,?,?)
        ON CONFLICT(supplier_id,item_id,period) DO UPDATE SET qty=excluded.qty""",
                   [(x.supplier_id, x.item_id, x.period.isoformat(), float(x.req)) for x in req.itertuples()])
    return sent


def record_commitment(db, msg_id, supplier_id, status, commit_qty=None, commit_date=None):
    """Capture Tier-2 confirmation (FR-6.2). Suppliers can only touch their own messages."""
    m = db.query("SELECT supplier_id FROM outbox WHERE msg_id=?", (msg_id,))
    if not m or m[0]["supplier_id"] != supplier_id:
        raise PermissionError("message not found for this supplier")
    if status not in ("CONFIRMED", "PARTIAL", "DECLINED"):
        raise ValueError("status must be CONFIRMED, PARTIAL or DECLINED")
    db.execute("UPDATE outbox SET commitment=?, commit_qty=?, commit_date=? WHERE msg_id=?",
               (status, commit_qty, commit_date, msg_id))
    db.audit(f"supplier:{supplier_id}", "tier2_commitment", str(msg_id), {"status": status, "qty": commit_qty})


# ---------------- ERP connector (read-mostly; writes limited to PO drafts) ----------------
class ERPConnector:
    """File-based connector. Replace with SAP RFC/OData for production; the interface stays the same."""
    def import_inventory(self, db, path, snapshot_date):
        df = pd.read_csv(path)   # item_id,item_type,on_hand,in_transit,age_days
        df["snapshot_date"] = snapshot_date
        db.executemany("""INSERT OR REPLACE INTO inventory_position(item_id,item_type,on_hand,in_transit,age_days,
            snapshot_date) VALUES(?,?,?,?,?,?)""",
                       df[["item_id", "item_type", "on_hand", "in_transit", "age_days", "snapshot_date"]].values.tolist())
        return len(df)

    def import_open_pos(self, db, path):
        df = pd.read_csv(path)   # po_id,item_id,supplier_id,qty,due_date
        db.executemany("INSERT OR REPLACE INTO open_po(po_id,item_id,supplier_id,qty,due_date) VALUES(?,?,?,?,?)",
                       df[["po_id", "item_id", "supplier_id", "qty", "due_date"]].values.tolist())
        return len(df)

    def export_po_drafts(self, db, out_dir):
        rows = db.query("SELECT * FROM po_draft WHERE exported=0")
        if not rows:
            return None
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, f"po_drafts_{dt.datetime.now():%Y%m%d_%H%M%S}.csv")
        with open(path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["draft_id", "item_id", "supplier_id", "qty", "due_date", "rec_id"],
                               extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)
        db.execute("UPDATE po_draft SET exported=1 WHERE exported=0")
        return path

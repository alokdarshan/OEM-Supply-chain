"""ADSPS - Adaptive Demand & Supply Planning System for Tier-1 automotive suppliers."""
__version__ = "1.0.0"

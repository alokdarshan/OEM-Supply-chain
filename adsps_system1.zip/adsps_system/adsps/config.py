"""Business-rule configuration (SRS FR-8.3): editable at runtime, persisted in DB, no redeploy."""
import copy
import json

DEFAULTS = {
    # Demand sensing: weight per horizon by days-until-period (SDD 3.2). Renormalised over available horizons.
    "horizon_weights": [
        {"max_days": 7,     "w": {"ABP": 0.00, "QRF": 0.00, "MFU": 0.10, "WDPA": 0.90}},
        {"max_days": 35,    "w": {"ABP": 0.00, "QRF": 0.05, "MFU": 0.35, "WDPA": 0.60}},
        {"max_days": 90,    "w": {"ABP": 0.05, "QRF": 0.25, "MFU": 0.70, "WDPA": 0.00}},
        {"max_days": 180,   "w": {"ABP": 0.20, "QRF": 0.60, "MFU": 0.20, "WDPA": 0.00}},
        {"max_days": 99999, "w": {"ABP": 0.60, "QRF": 0.35, "MFU": 0.05, "WDPA": 0.00}},
    ],
    "planning_horizon_weeks": 26,
    "history_window_weeks": 52,
    # Volatility index (SDD 6.3)
    "vi_weights": {"volume": 0.4, "mix": 0.3, "swing": 0.3},
    "vi_scales": {"volume": 0.30, "mix": 0.50, "swing": 0.40},   # value that maps to component = 1.0
    "base_cv": 0.05,     # forecast uncertainty floor (fraction of demand)
    "vol_k": 0.35,       # extra CV per unit of volatility index
    # Procurement (SDD 3.5 / 6.2)
    "service_levels": {"A": 0.98, "B": 0.95, "C": 0.90},
    "posture_offset": {"conservative": 0.03, "balanced": 0.0, "aggressive": -0.10},
    "default_posture": "balanced",
    "review_weeks": 1,
    "ordering_cost": 2500.0,     # Rs per PO
    "holding_rate": 0.22,        # annual, fraction of unit cost
    "po_cover_weeks": 8,         # open PO is 'excess' if it lifts stock above SS + this many weeks of demand
    "expedite_premium": 0.35,    # logistics premium on shortage value (air vs road)
    "shortage_penalty_factor": 1.5,
    # Inventory health (SDD 3.6)
    "target_ratio": {"FG": 1.0, "RM": 3.0, "BOP": 2.0},
    "ratio_tolerance": 0.25,
    # Alerting (SDD 3.7)
    "alert_thresholds": {"spike_pct": 0.15, "drop_pct": 0.15, "mix_pp": 0.08, "capacity_pct": 0.20},
    "sla_hours": {"high": 4, "medium": 24, "low": 72},
    "alert_owner": {"demand-spike": "demand_planner", "demand-drop": "demand_planner",
                    "mix-shift": "plant_manager", "capacity-risk": "plant_manager",
                    "PO-conflict": "procurement"},
    # ML demand sensing (SDD 3.3)
    "ml": {"enabled": True, "trust_weight": 0.6, "min_improvement": 0.05, "min_rows": 200,
           "retrain_days": 30, "drift_tol": 0.25, "festival_months": [3, 9, 10, 11]},
    # Tier-2 collaboration
    "tier2": {"share_threshold": 0.10, "horizon_weeks": 6},
}


def deep_merge(base, patch):
    out = copy.deepcopy(base)
    for k, v in (patch or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(db):
    rows = db.query("SELECT value FROM config WHERE key='main'")
    return deep_merge(DEFAULTS, json.loads(rows[0]["value"])) if rows else copy.deepcopy(DEFAULTS)


def save_config(db, patch, actor="admin"):
    stored = db.query("SELECT value FROM config WHERE key='main'")
    cur = json.loads(stored[0]["value"]) if stored else {}
    new = deep_merge(cur, patch)
    db.execute("INSERT INTO config(key,value) VALUES('main',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(new),))
    db.audit(actor, "config_change", "config", patch)
    return load_config(db)

"""Procurement Optimization Engine (SDD 3.5 / 6.2; SRS FR-3.x).
Dynamic safety stock SS = Z * sigma_LT (sigma from measured volatility), EOQ + MOQ sizing, risk postures,
and open-PO reconciliation. Output is DRAFT recommendations only (never autonomous ERP writes)."""
import datetime as dt
import json
import math
from statistics import NormalDist

import numpy as np
import pandas as pd

from .ingestion import week_start

ND = NormalDist()


def z_for(sl):
    return ND.inv_cdf(min(max(sl, 0.5), 0.9995))


def loss(z):
    """Standard normal loss function L(z) = phi(z) - z(1-Phi(z))."""
    return ND.pdf(z) - z * (1 - ND.cdf(z))


def _round_lot(q, moq):
    return math.ceil(q / moq) * moq if q > 0 and moq and moq > 0 else max(q, 0.0)


def run(db, cfg, recon, sku_metrics, as_of):
    """Returns (recommendations_df, item_state_df, po_conflicts_df)."""
    cur = week_start(as_of)
    H = cfg["planning_horizon_weeks"]
    periods = [cur + dt.timedelta(weeks=i) for i in range(H)]
    skus = sorted(recon["sku_id"].unique())
    sidx = {s: i for i, s in enumerate(skus)}
    D, S = np.zeros((len(skus), H)), np.zeros((len(skus), H))
    pidx = {p: i for i, p in enumerate(periods)}
    for r in recon.itertuples():
        if r.period in pidx:
            D[sidx[r.sku_id], pidx[r.period]] = r.reconciled
            S[sidx[r.sku_id], pidx[r.period]] = r.sigma

    items = db.df("""SELECT i.item_id, i.item_type, i.unit_cost, s.supplier_id, s.lead_time_days, s.moq
                     FROM item i JOIN supplier s USING(item_id)""").drop_duplicates("item_id").reset_index(drop=True)
    bom = db.df("SELECT item_id, sku_id, qty_per_unit FROM bom_item")
    bom = bom[bom["sku_id"].isin(sidx)]
    iidx = {it: i for i, it in enumerate(items["item_id"])}
    B = np.zeros((len(items), len(skus)))
    for r in bom.itertuples():
        if r.item_id in iidx:
            B[iidx[r.item_id], sidx[r.sku_id]] = r.qty_per_unit
    ID, IV = B @ D, (B ** 2) @ (S ** 2)          # item demand, item variance (weeks x items)

    inv = db.df("""SELECT item_id, on_hand, in_transit, age_days FROM inventory_position
                   WHERE snapshot_date=(SELECT MAX(snapshot_date) FROM inventory_position)""").set_index("item_id")
    pos_df = db.df("SELECT * FROM open_po WHERE status='OPEN'")
    if len(pos_df):
        pos_df["due"] = pd.to_datetime(pos_df["due_date"]).dt.date
    vi = sku_metrics.set_index("sku_id")["vi"]
    abc = sku_metrics.set_index("sku_id")["abc_class"]

    recs, states, conflicts = [], [], []
    for it in items.itertuples():
        i = iidx[it.item_id]
        dem, var = ID[i], IV[i]
        if dem.sum() <= 0:
            continue
        L = max(1, math.ceil(it.lead_time_days / 7))
        R = cfg["review_weeks"]
        cover = min(L + R, H)
        d_lt = float(dem[:cover].sum())
        sig = float(math.sqrt(var[:cover].sum()))
        wk = float(dem.mean())
        # item risk class: worst (most critical) ABC class among consuming SKUs, weighted by usage
        users = bom[bom["item_id"] == it.item_id]["sku_id"]
        item_vi = float(np.average([vi.get(s, 0.3) for s in users])) if len(users) else 0.3
        cls = min((abc.get(s, "C") for s in users), default="C")
        on_hand = float(inv["on_hand"].get(it.item_id, 0.0)) if len(inv) else 0.0
        in_tr = float(inv["in_transit"].get(it.item_id, 0.0)) if len(inv) else 0.0
        age = float(inv["age_days"].get(it.item_id, 0.0)) if len(inv) else 0.0
        my_pos = pos_df[pos_df["item_id"] == it.item_id] if len(pos_df) else pos_df
        po_qty = float(my_pos["qty"].sum()) if len(my_pos) else 0.0
        position = on_hand + in_tr + po_qty
        h_cost = it.unit_cost * cfg["holding_rate"]
        eoq = math.sqrt(2 * wk * 52 * cfg["ordering_cost"] / h_cost) if h_cost > 0 else wk * 4
        eoq = max(eoq, wk)

        base_sl = cfg["service_levels"][cls]
        alts = {}
        for name, off in cfg["posture_offset"].items():
            sl = min(base_sl + off, 0.999)
            z = z_for(sl)
            ss = z * sig
            rop = d_lt + ss
            need = max(0.0, rop + eoq - position) if position <= rop else 0.0
            qty = _round_lot(max(need, eoq) if position <= rop else 0.0, it.moq)
            exp_short = sig * loss(z)
            alts[name] = {"service_level": round(sl, 4), "z": round(z, 3), "safety_stock": ss, "rop": rop,
                          "order_qty": qty, "expected_stockout_prob": round(1 - sl, 4),
                          "expected_shortage_units": exp_short,
                          "expected_excess_units": ss + exp_short + qty / 2 if qty else ss + exp_short,
                          "expected_excess_value": (ss + exp_short) * it.unit_cost}
        pick = alts[cfg["default_posture"]]
        ss, rop = pick["safety_stock"], pick["rop"]

        # timing: first week the position (without new orders) breaches safety stock
        cum = np.cumsum(dem)
        breach = next((t for t in range(H) if position - cum[t] <= ss), None)
        today = as_of
        if position <= rop:
            action, when = "ORDER_NOW", today
        elif breach is not None:
            when = max(today, cur + dt.timedelta(weeks=breach) - dt.timedelta(days=int(it.lead_time_days)))
            action = "ORDER_NOW" if when <= today else "PLANNED_ORDER"
        else:
            action, when = "NO_ACTION", None
        qty = pick["order_qty"] if action != "NO_ACTION" else 0.0
        if action == "PLANNED_ORDER" and qty == 0:
            qty = _round_lot(eoq, it.moq)

        # excess / shortage exposure
        max_level = ss + d_lt + eoq / 2
        excess = max(0.0, on_hand + in_tr - max_level)
        proj_short = max(0.0, d_lt - (on_hand + in_tr + (my_pos[my_pos["due"] <= cur + dt.timedelta(weeks=L)]["qty"].sum()
                                                          if len(my_pos) else 0.0)))
        states.append({"item_id": it.item_id, "supplier_id": it.supplier_id, "weekly_demand": wk,
                       "demand_lt": d_lt, "sigma_lt": sig, "safety_stock": ss, "rop": rop, "position": position,
                       "eoq": eoq, "excess_units": excess, "short_units": proj_short,
                       "excess_value": excess * it.unit_cost, "short_value": proj_short * it.unit_cost,
                       "weeks_cover": (on_hand + in_tr) / wk if wk else None, "vi": item_vi, "abc_class": cls})
        explain = {"lead_time_days": int(it.lead_time_days), "moq": it.moq, "demand_during_lt": d_lt,
                   "sigma_lt": sig, "volatility_index": item_vi, "abc_class": cls, "z": pick["z"],
                   "safety_stock": ss, "rop": rop, "eoq": eoq, "on_hand": on_hand, "in_transit": in_tr,
                   "open_po_qty": po_qty, "position": position, "age_days": age,
                   "formula": "SS = Z x sigma_LT; ROP = demand_LT + SS; order = max(ROP+EOQ-position, EOQ) rounded to MOQ"}
        recs.append({"item_id": it.item_id, "run_date": as_of.isoformat(), "action": action,
                     "recommended_qty": qty, "recommended_date": when.isoformat() if when else None,
                     "risk_posture": cfg["default_posture"], "explain_json": json.dumps(explain),
                     "alt_json": json.dumps(alts)})

        # ---- open-PO reconciliation (FR-3.5) ----
        if len(my_pos):
            conflicts += _po_conflicts(it, my_pos, dem, on_hand + in_tr, ss, cur, H, cfg, as_of)
    return pd.DataFrame(recs), pd.DataFrame(states), pd.DataFrame(conflicts)


def _po_conflicts(it, pos, dem, start_stock, ss, cur, H, cfg, as_of):
    out = []
    recv = np.zeros(H)
    wk_of = {}
    for p in pos.itertuples():
        w = min(max((p.due - cur).days // 7, 0), H - 1)
        recv[w] += p.qty
        wk_of[p.po_id] = (w, p.qty)
    stock_with = start_stock + np.cumsum(recv) - np.cumsum(dem)
    for po_id, (w, qty) in wk_of.items():
        excl = stock_with.copy()
        excl[w:] -= qty
        cover_end = min(w + cfg["po_cover_weeks"], H)
        max_level = ss + dem[w:cover_end].sum()
        if excl[:w + 1].min() < ss and w > 0 and excl[:w].min() < 0:
            out.append({"run_date": as_of.isoformat(), "po_id": po_id, "item_id": it.item_id,
                        "conflict_type": "LATE_SHORTAGE",
                        "suggestion": f"Stock-out projected before PO due week +{w}; expedite or add safety cover",
                        "qty_affected": float(-excl[:w].min())})
        elif stock_with[w] > max_level:
            exc = float(min(qty, stock_with[w] - max_level))
            push = next((t for t in range(w, H) if excl[t] <= ss), H)
            sugg = (f"Cancel/reduce by ~{exc:.0f}" if exc >= qty * 0.99 or push >= H
                    else f"Reschedule ~{exc:.0f} by +{push - w} week(s)")
            out.append({"run_date": as_of.isoformat(), "po_id": po_id, "item_id": it.item_id,
                        "conflict_type": "EXCESS", "suggestion": sugg, "qty_affected": exc})
    return out


def decide(db, rec_id, decision, actor, reason=None, final_qty=None):
    """Planner accept/override (FR-3.6). Override requires a reason. Accept creates an ERP PO *draft*."""
    r = db.query("SELECT * FROM recommendation WHERE rec_id=?", (rec_id,))
    if not r:
        raise KeyError("recommendation not found")
    r = r[0]
    if r["status"] != "DRAFT":
        raise ValueError(f"recommendation already {r['status']}")
    decision = decision.lower()
    if decision == "override":
        if not reason or final_qty is None:
            raise ValueError("override requires reason and final_qty")
        status, qty = "OVERRIDDEN", float(final_qty)
    elif decision == "accept":
        status, qty = "ACCEPTED", float(r["recommended_qty"])
    else:
        raise ValueError("decision must be accept or override")
    from .db import utcnow
    db.execute("""UPDATE recommendation SET status=?, final_qty=?, decision_reason=?, decided_by=?, decided_at=?
                  WHERE rec_id=?""", (status, qty, reason, actor, utcnow(), rec_id))
    if qty > 0:
        sup = db.query("SELECT supplier_id FROM supplier WHERE item_id=? LIMIT 1", (r["item_id"],))
        db.execute("""INSERT INTO po_draft(rec_id,item_id,supplier_id,qty,due_date,created_at) VALUES(?,?,?,?,?,?)""",
                   (rec_id, r["item_id"], sup[0]["supplier_id"] if sup else None, qty,
                    r["recommended_date"], utcnow()))
    db.audit(actor, f"recommendation_{status.lower()}", str(rec_id),
             {"item": r["item_id"], "recommended": r["recommended_qty"], "final": qty, "reason": reason})
    return {"rec_id": rec_id, "status": status, "final_qty": qty}

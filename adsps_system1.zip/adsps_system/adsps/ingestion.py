"""Forecast Ingestion Service (SDD 3.1; SRS FR-1.x).
Validates, maps OEM variant codes to SKUs, quarantines bad rows, appends immutable ForecastVersion records."""
import datetime as dt
import json
import math

import pandas as pd

from .db import utcnow

HORIZONS = ("ABP", "QRF", "MFU", "WDPA")


def to_date(v):
    if v is None or (isinstance(v, float) and math.isnan(v)):
        raise ValueError("missing date")
    return pd.to_datetime(v).date()


def week_start(d):
    d = to_date(d)
    return d - dt.timedelta(days=d.weekday())


def ingest_records(db, records, source_file_ref="api", actor="system", bus=None):
    """records: dicts with oem_id, variant_code, horizon_type, forecast_date, effective_period, quantity
    (optional: plant_id, ingested_at). Returns a summary incl. the new forecast_id range."""
    vm = {(r["oem_id"], r["variant_code"]): r for r in db.query(
        "SELECT v.oem_id, v.variant_code, v.sku_id, s.plant_id FROM variant_map v JOIN sku s USING(sku_id)")}
    now = utcnow()
    good, bad = [], []
    for r in records:
        try:
            oem = str(r["oem_id"])
            code = str(r.get("variant_code") or r.get("model_variant") or r["oem_variant_code"])
            h = str(r["horizon_type"]).upper()
            if h not in HORIZONS:
                raise ValueError(f"unknown horizon {h}")
            q = float(r["quantity"])
            if not math.isfinite(q) or q < 0:
                raise ValueError("quantity must be a non-negative number")
            m = vm.get((oem, code))
            if m is None:
                raise ValueError(f"unmapped variant {oem}/{code}")
            period = week_start(r["effective_period"])
            fdate = to_date(r.get("forecast_date") or dt.date.today())
            good.append((oem, r.get("plant_id") or m["plant_id"], m["sku_id"], code, h, fdate.isoformat(),
                         period.isoformat(), q, source_file_ref, r.get("ingested_at") or now,
                         r.get("entry_type", "ingest")))
        except Exception as e:  # row-level quarantine; never block the batch
            bad.append((source_file_ref, json.dumps(r, default=str), str(e), now))
    first = last = None
    with db.lock:
        before = db.query("SELECT COALESCE(MAX(forecast_id),0) m FROM forecast_version")[0]["m"]
        if good:
            db.executemany("""INSERT INTO forecast_version(oem_id,plant_id,sku_id,variant_code,horizon_type,
                forecast_date,effective_period,quantity,source_file_ref,ingested_at,entry_type)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)""", good)
            after = db.query("SELECT MAX(forecast_id) m FROM forecast_version")[0]["m"]
            first, last = before + 1, after
        if bad:
            db.executemany("INSERT INTO quarantine(source_file_ref,record_json,reason,ingested_at) VALUES(?,?,?,?)", bad)
    summary = {"accepted": len(good), "quarantined": len(bad), "first_id": first, "last_id": last,
               "source_file_ref": source_file_ref}
    db.audit(actor, "ingest", source_file_ref, {k: summary[k] for k in ("accepted", "quarantined")})
    if bus and good:
        bus.publish("ingestion_complete", summary)
    return summary


def load_file(path, horizon_type=None, oem_id=None, aggregate_daily=False):
    """Read a CSV/Excel OEM file into record dicts. Columns (case-insensitive): oem_id, variant_code,
    horizon_type, forecast_date, effective_period, quantity[, plant_id]. horizon/oem may be given as args."""
    df = pd.read_excel(path) if str(path).lower().endswith((".xlsx", ".xls")) else pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]
    if horizon_type:
        df["horizon_type"] = horizon_type
    if oem_id:
        df["oem_id"] = oem_id
    if aggregate_daily:  # daily WDPA rows -> weekly buckets
        df["effective_period"] = df["effective_period"].map(week_start)
        keys = [c for c in ("oem_id", "plant_id", "variant_code", "horizon_type", "forecast_date",
                            "effective_period") if c in df.columns]
        df = df.groupby(keys, as_index=False)["quantity"].sum()
    return df.to_dict("records")


def correct_forecast(db, forecast_id, new_qty, reason, actor):
    """Manual correction (FR-1.4): appends a new version (never edits) and writes an audit trail."""
    row = db.query("SELECT * FROM forecast_version WHERE forecast_id=?", (forecast_id,))
    if not row:
        raise KeyError("forecast_id not found")
    o = row[0]
    cur = db.execute("""INSERT INTO forecast_version(oem_id,plant_id,sku_id,variant_code,horizon_type,forecast_date,
        effective_period,quantity,source_file_ref,ingested_at,entry_type) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                     (o["oem_id"], o["plant_id"], o["sku_id"], o["variant_code"], o["horizon_type"],
                      o["forecast_date"], o["effective_period"], float(new_qty), f"manual-correction:{forecast_id}",
                      utcnow(), "manual-correction"))
    db.audit(actor, "forecast_correction", str(forecast_id),
             {"old": o["quantity"], "new": new_qty, "reason": reason, "new_id": cur.lastrowid})
    return cur.lastrowid

"""ML-based Demand Sensing (SDD 3.3, rev1): one model per OEM learns the OEM's forecast-bias signature
and pre-corrects new forecasts. Gradient-boosted trees, with an EWMA bias baseline as fallback.
Governance: a model influences plans only if it beats the best non-ML baseline on held-out history."""
import datetime as dt
import pickle

import numpy as np
import pandas as pd

from .db import utcnow
from .ingestion import HORIZONS, week_start

try:
    from sklearn.ensemble import GradientBoostingRegressor
except Exception:  # pragma: no cover
    GradientBoostingRegressor = None

HZ_IDX = {h: i for i, h in enumerate(HORIZONS)}
LAG = {"ABP": 26, "QRF": 10, "MFU": 4, "WDPA": 1}       # approx. weeks between issue and period
FEATS = ["h", "logq", "rev", "month", "festival", "prior_err", "mix", "lead_wk"]


def _feat(df, cfg):
    f = pd.DataFrame(index=df.index)
    f["h"] = df["h"].map(HZ_IDX)
    f["logq"] = np.log1p(df["q"])
    f["rev"] = (df["q"] / df["prev_q"].replace(0, np.nan)).fillna(1.0).clip(0.2, 5)
    per = pd.to_datetime(df["period"])
    f["month"] = per.dt.month
    f["festival"] = per.dt.month.isin(cfg["ml"]["festival_months"]).astype(int)
    f["prior_err"] = df["prior_err"]
    f["mix"] = df["mix"]
    f["lead_wk"] = df["h"].map(LAG)
    return f[FEATS]


def _long(wide, oem_id, mix_by_sku):
    """Long frame: one row per (sku, period, horizon) with revision context."""
    w = wide[wide["oem_id"] == oem_id].reset_index()
    parts = []
    for i, h in enumerate(HORIZONS):
        prev = w[HORIZONS[i - 1]] if i > 0 else w[h]
        prev = prev.where(prev.notna(), w[h])
        p = pd.DataFrame({"sku_id": w["sku_id"], "period": w["period"], "h": h, "q": w[h], "prev_q": prev})
        parts.append(p[p["q"].notna() & (p["q"] > 0)])
    L = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
    L["mix"] = L["sku_id"].map(mix_by_sku).fillna(0.0)
    return L


def _prior_err_train(L):
    """Lagged rolling mean of past actual/forecast ratios (what was knowable when the forecast was issued)."""
    L = L.sort_values(["sku_id", "h", "period"]).copy()
    L["ratio"] = L["actual"] / L["q"]
    out = []
    for (sku, h), g in L.groupby(["sku_id", "h"], sort=False):
        out.append(g["ratio"].shift(LAG[h]).rolling(4, min_periods=1).mean())
    L["prior_err"] = pd.concat(out).reindex(L.index).fillna(1.0)
    return L


def build_training(wide, actuals, oem_id, mix_by_sku, as_of):
    L = _long(wide, oem_id, mix_by_sku)
    if L.empty or actuals.empty:
        return pd.DataFrame()
    L = L.merge(actuals.rename("actual").reset_index(), on=["sku_id", "period"], how="inner")
    L = L[(L["actual"] > 0) & (L["period"] < week_start(as_of))]
    return _prior_err_train(L) if len(L) else pd.DataFrame()


def _mape(a, f):
    return float(np.mean(np.abs(a - f) / a))


def train_oem(wide, actuals, oem_id, mix_by_sku, cfg, as_of):
    """Returns (model_dict, metrics_dict)."""
    T = build_training(wide, actuals, oem_id, mix_by_sku, as_of)
    mc = cfg["ml"]
    info = {"oem_id": oem_id, "n_rows": len(T), "mape_raw": None, "mape_baseline": None, "mape_model": None,
            "approved": 0, "model_type": "none"}
    if len(T) < mc["min_rows"]:
        return None, info
    T = T.sort_values("period")
    X = _feat(T, cfg)
    y = (T["actual"] / T["q"]).clip(0.4, 2.5)
    cut = T["period"].quantile(0.75, interpolation="lower")
    tr, va = (T["period"] <= cut).to_numpy(), (T["period"] > cut).to_numpy()
    if va.sum() < 30:
        return None, info
    a, q = T["actual"].to_numpy(), T["q"].to_numpy()
    raw = _mape(a[va], q[va])
    base = _mape(a[va], q[va] * T["prior_err"].to_numpy()[va])
    model, mtype = None, "ewma-baseline"
    pred_va = T["prior_err"].to_numpy()[va]
    if GradientBoostingRegressor is not None:
        model = GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.05, subsample=0.8,
                                          random_state=7).fit(X[tr], y[tr])
        pred_va = model.predict(X[va])
        mtype = "gradient-boosting"
    m = _mape(a[va], q[va] * pred_va)
    best_non_ml = min(raw, base) if mtype == "gradient-boosting" else raw
    approved = int(m <= best_non_ml * (1 - mc["min_improvement"]))
    resid = a[va] / (q[va] * pred_va) - 1
    if model is not None:
        model = GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.05, subsample=0.8,
                                          random_state=7).fit(X, y)   # refit on all history
    obj = {"model": model, "type": mtype, "q10": float(np.quantile(resid, 0.1)),
           "q90": float(np.quantile(resid, 0.9)),
           "importances": dict(zip(FEATS, model.feature_importances_)) if model is not None else {}}
    info.update(mape_raw=raw, mape_baseline=base, mape_model=m, approved=approved, model_type=mtype)
    return obj, info


def _predict_ratio(obj, F):
    if obj["model"] is not None:
        return np.clip(obj["model"].predict(F), 0.4, 2.5)
    return F["prior_err"].to_numpy()


def _recent_ratios(wide, actuals, oem_id, as_of):
    """Latest 4 completed actual/forecast ratios per (sku, horizon) -> prior_err for new forecasts."""
    L = _long(wide, oem_id, {})
    if L.empty or actuals.empty:
        return pd.Series(dtype=float)
    L = L.merge(actuals.rename("actual").reset_index(), on=["sku_id", "period"])
    L = L[(L["actual"] > 0) & (L["period"] < week_start(as_of))].sort_values("period")
    L["ratio"] = L["actual"] / L["q"]
    return L.groupby(["sku_id", "h"])["ratio"].apply(lambda s: s.tail(4).mean())


def retrain_if_needed(db, wide, actuals, mix_by_sku, cfg, as_of, force=False):
    """Monthly retrain, or earlier when error drift exceeds tolerance (SDD 3.3.1)."""
    out = {}
    for oem in wide["oem_id"].dropna().unique():
        row = db.query("SELECT * FROM ml_model WHERE oem_id=?", (oem,))
        need = force or not row
        if row and not need:
            age = (as_of - dt.date.fromisoformat(row[0]["trained_at"])).days
            need = age >= cfg["ml"]["retrain_days"]
            if not need and row[0]["approved"] and row[0]["mape_model"]:
                need = _drift(row[0], wide, actuals, oem, mix_by_sku, cfg, as_of) > cfg["ml"]["drift_tol"]
        if need:
            obj, info = train_oem(wide, actuals, oem, mix_by_sku, cfg, as_of)
            db.execute("""INSERT INTO ml_model(oem_id,trained_at,model_type,n_rows,mape_raw,mape_baseline,mape_model,
                approved,blob) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(oem_id) DO UPDATE SET
                trained_at=excluded.trained_at, model_type=excluded.model_type, n_rows=excluded.n_rows,
                mape_raw=excluded.mape_raw, mape_baseline=excluded.mape_baseline, mape_model=excluded.mape_model,
                approved=excluded.approved, blob=excluded.blob""",
                       (oem, as_of.isoformat(), info["model_type"], info["n_rows"], info["mape_raw"],
                        info["mape_baseline"], info["mape_model"], info["approved"], pickle.dumps(obj)))
            db.audit("system", "ml_retrain", oem, info)
            out[oem] = info
    return out


def _drift(row, wide, actuals, oem, mix_by_sku, cfg, as_of):
    obj = pickle.loads(row["blob"])
    if obj is None:
        return 0.0
    T = build_training(wide, actuals, oem, mix_by_sku, as_of)
    if T.empty:
        return 0.0
    T = T[T["period"] >= week_start(as_of) - dt.timedelta(weeks=8)]
    if len(T) < 20:
        return 0.0
    m = _mape(T["actual"].to_numpy(), T["q"].to_numpy() * _predict_ratio(obj, _feat(T, cfg)))
    return m / row["mape_model"] - 1


def predict(db, wide, actuals, mix_by_sku, cfg, as_of):
    """Bias-corrected quantity + interval for each future SKU/period, using the finest available horizon.
    Only OEMs with an *approved* model are returned (others fall back to rule-based reconciliation)."""
    frames = []
    cur = week_start(as_of)
    if not cfg["ml"]["enabled"]:
        return pd.DataFrame()
    for row in db.query("SELECT * FROM ml_model WHERE approved=1"):
        obj = pickle.loads(row["blob"])
        oem = row["oem_id"]
        w = wide[wide["oem_id"] == oem].reset_index()
        w = w[w["period"] >= cur]
        if w.empty:
            continue
        prior = _recent_ratios(wide, actuals, oem, as_of)
        recs = []
        for _, r in w.iterrows():
            avail = [h for h in HORIZONS if pd.notna(r[h]) and r[h] > 0]
            if not avail:
                continue
            h = avail[-1]
            prev = r[avail[-2]] if len(avail) > 1 else r[h]
            recs.append({"sku_id": r["sku_id"], "period": r["period"], "h": h, "q": r[h], "prev_q": prev,
                         "prior_err": float(prior.get((r["sku_id"], h), 1.0)),
                         "mix": float(mix_by_sku.get(r["sku_id"], 0.0))})
        P = pd.DataFrame(recs)
        if P.empty:
            continue
        F = _feat(P, cfg)
        ratio = _predict_ratio(obj, F)
        P["ml_qty"] = P["q"] * ratio
        P["ml_lo"] = P["ml_qty"] * (1 + obj["q10"])
        P["ml_hi"] = P["ml_qty"] * (1 + obj["q90"])
        P["ml_weight"] = cfg["ml"]["trust_weight"]
        top = sorted(obj["importances"].items(), key=lambda kv: -kv[1])[:3]
        drivers = ", ".join(k for k, _ in top) if top else "recent bias (EWMA)"
        P["ml_note"] = [f"{h} {q:.0f} x{rt:.3f} -> {m:.0f} (drivers: {drivers})"
                        for h, q, rt, m in zip(P["h"], P["q"], ratio, P["ml_qty"])]
        frames.append(P.set_index(["sku_id", "period"])[["ml_qty", "ml_lo", "ml_hi", "ml_weight", "ml_note"]])
    return pd.concat(frames) if frames else pd.DataFrame()


def model_report(db):
    return db.query("""SELECT oem_id, trained_at, model_type, n_rows, mape_raw, mape_baseline, mape_model, approved
                       FROM ml_model""")

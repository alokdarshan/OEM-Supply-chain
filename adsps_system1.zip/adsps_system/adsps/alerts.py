"""Alerting & Workflow Engine (SDD 3.7; SRS FR-5.x) - the system equivalent of the manual 'line monitor'."""
import datetime as dt
import json

import pandas as pd

from .db import utcnow

BASELINE = {"WDPA": "MFU", "MFU": "QRF"}      # compare new data against the previous horizon


def _severity(mag, thr):
    return "high" if mag >= 2 * thr else "medium" if mag >= 1.5 * thr else "low"


def raise_alert(db, cfg, type_, severity, owner=None, sku_id=None, item_id=None, period=None, detail=None):
    """Creates an alert unless an identical one is already open (dedupe)."""
    dup = db.query("""SELECT alert_id FROM alert WHERE status='open' AND type=? AND COALESCE(sku_id,'')=?
                      AND COALESCE(item_id,'')=? AND COALESCE(period,'')=?""",
                   (type_, sku_id or "", item_id or "", period or ""))
    if dup:
        return None
    now = dt.datetime.fromisoformat(utcnow())
    due = now + dt.timedelta(hours=cfg["sla_hours"][severity])
    cur = db.execute("""INSERT INTO alert(type,sku_id,item_id,period,severity,owner,detail,created_at,sla_due)
                        VALUES(?,?,?,?,?,?,?,?,?)""",
                     (type_, sku_id, item_id, period, severity, owner or cfg["alert_owner"].get(type_, "demand_planner"),
                      json.dumps(detail, default=str), now.isoformat(timespec="seconds"),
                      due.isoformat(timespec="seconds")))
    return cur.lastrowid


def evaluate_ingestion(db, cfg, first_id, last_id):
    """Rule engine run after each ingestion batch: demand spike/drop, mix shift, capacity risk."""
    if first_id is None:
        return []
    th = cfg["alert_thresholds"]
    new = db.df("""SELECT * FROM forecast_version WHERE forecast_id BETWEEN ? AND ? AND horizon_type IN ('WDPA','MFU')""",
                (first_id, last_id))
    if new.empty:
        return []
    keys = new["sku_id"].unique().tolist()
    q = ",".join("?" * len(keys))
    allv = db.df(f"""SELECT forecast_id bid, sku_id, effective_period, horizon_type bh, forecast_date bfd, quantity base
                     FROM forecast_version WHERE sku_id IN ({q}) AND horizon_type IN ('QRF','MFU')""", keys)
    created = []
    new["bh"] = new["horizon_type"].map(BASELINE)
    new = new.reset_index(drop=True).rename_axis("nid").reset_index()
    j = new[["nid", "sku_id", "effective_period", "bh", "forecast_id"]].merge(
        allv, on=["sku_id", "effective_period", "bh"])
    j = j[j["bid"] < j["forecast_id"]].sort_values(["bfd", "bid"]).drop_duplicates("nid", keep="last")
    new = new.merge(j[["nid", "base"]], on="nid", how="left")
    n = new.dropna(subset=["base"])
    n = n[n["base"] > 0].copy()
    n["delta"] = (n["quantity"] - n["base"]) / n["base"]
    for r in n.itertuples():
        if r.delta >= th["spike_pct"] or r.delta <= -th["drop_pct"]:
            typ = "demand-spike" if r.delta > 0 else "demand-drop"
            thr = th["spike_pct"] if r.delta > 0 else th["drop_pct"]
            aid = raise_alert(db, cfg, typ, _severity(abs(r.delta), thr), sku_id=r.sku_id, period=r.effective_period,
                              detail={"horizon": r.horizon_type, "baseline": r.base, "new": r.quantity,
                                      "delta_pct": round(r.delta * 100, 1)})
            if aid: created.append(aid)
    # mix shift & capacity risk per plant/period/horizon
    for (plant, per, hz), g in n.groupby(["plant_id", "effective_period", "horizon_type"]):
        tot_new, tot_base = g["quantity"].sum(), g["base"].sum()
        if len(g) < 2 or tot_new <= 0 or tot_base <= 0:
            continue
        g = g.assign(sn=g["quantity"] / tot_new, sb=g["base"] / tot_base)
        for r in g.itertuples():
            pp = r.sn - r.sb
            if abs(pp) >= th["mix_pp"]:
                aid = raise_alert(db, cfg, "mix-shift", _severity(abs(pp), th["mix_pp"]), sku_id=r.sku_id,
                                  period=per, detail={"plant": plant, "horizon": hz, "share_before": round(r.sb, 3),
                                                      "share_after": round(r.sn, 3), "shift_pp": round(pp * 100, 1)})
                if aid: created.append(aid)
        swing = tot_new / tot_base - 1
        if abs(swing) >= th["capacity_pct"]:
            aid = raise_alert(db, cfg, "capacity-risk", _severity(abs(swing), th["capacity_pct"]), sku_id=None,
                              period=per, detail={"plant": plant, "horizon": hz, "plant_volume_change_pct": round(swing * 100, 1),
                                                  "hint": "overtime" if swing > 0 else "idle capacity"})
            if aid: created.append(aid)
    return created


def raise_po_conflict_alerts(db, cfg, conflicts):
    n = 0
    for c in conflicts.itertuples() if len(conflicts) else []:
        sev = "high" if c.conflict_type == "LATE_SHORTAGE" else "medium"
        if raise_alert(db, cfg, "PO-conflict", sev, item_id=c.item_id, period=c.po_id,
                       detail={"po_id": c.po_id, "type": c.conflict_type, "suggestion": c.suggestion,
                               "qty_affected": c.qty_affected}):
            n += 1
    return n


def list_alerts(db, status="open", role=None):
    sql, p = "SELECT * FROM alert WHERE status=?", [status]
    if role and role not in ("admin", "executive"):
        sql += " AND owner=?"
        p.append(role)
    return db.query(sql + " ORDER BY CASE severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END, alert_id", p)


def resolve(db, alert_id, notes, actor):
    if not notes:
        raise ValueError("resolution notes required")
    r = db.query("SELECT status FROM alert WHERE alert_id=?", (alert_id,))
    if not r:
        raise KeyError("alert not found")
    db.execute("UPDATE alert SET status='resolved', resolved_at=?, resolution=?, resolved_by=? WHERE alert_id=?",
               (utcnow(), notes, actor, alert_id))
    db.audit(actor, "alert_resolved", str(alert_id), {"notes": notes})


def sla_breaches(db):
    return db.query("SELECT * FROM alert WHERE status='open' AND sla_due < ?", (utcnow(),))

"""Inventory Health Module (SDD 3.6; SRS FR-4.x): FG:RM:BOP ratio drift, obsolescence risk, working-capital exposure."""
import datetime as dt

import numpy as np
import pandas as pd


def health(db, cfg, item_state, sku_metrics, recon, as_of):
    inv = db.df("""SELECT p.item_id, p.item_type, p.on_hand, p.in_transit, p.age_days
                   FROM inventory_position p WHERE snapshot_date=(SELECT MAX(snapshot_date) FROM inventory_position)""")
    if inv.empty:
        return {"ratio": {}, "families": [], "obsolescence": [], "working_capital": {}}
    skus = db.df("SELECT sku_id, family, unit_cost, program_end FROM sku")
    items = db.df("SELECT item_id, unit_cost FROM item")
    cost = dict(zip(items["item_id"], items["unit_cost"])) | dict(zip(skus["sku_id"], skus["unit_cost"]))
    inv["value"] = (inv["on_hand"] + inv["in_transit"]) * inv["item_id"].map(cost).fillna(0)

    # family attribution: FG by own family; RM/BOP split equally across consuming SKUs' families
    fam_of = skus.set_index("sku_id")["family"]
    bom = db.df("SELECT item_id, sku_id FROM bom_item")
    bom["family"] = bom["sku_id"].map(fam_of)
    fam_share = {}
    for (iid, f), n in bom.groupby(["item_id", "family"]).size().items():
        fam_share.setdefault(iid, {})[f] = n
    fam_share = {i: {f: n / sum(d.values()) for f, n in d.items()} for i, d in fam_share.items()}
    rows = []
    for r in inv.itertuples():
        if r.item_type == "FG":
            rows.append((fam_of.get(r.item_id), "FG", r.value))
        else:
            for f, sh in fam_share.get(r.item_id, {}).items():
                rows.append((f, r.item_type, r.value * sh))
    fam = pd.DataFrame(rows, columns=["family", "type", "value"]).pivot_table(
        index="family", columns="type", values="value", aggfunc="sum").fillna(0)
    for t in ("FG", "RM", "BOP"):
        if t not in fam:
            fam[t] = 0.0
    tgt, tol = cfg["target_ratio"], cfg["ratio_tolerance"]

    def ratio(row):
        fg = row["FG"] if row["FG"] > 0 else None
        if not fg:
            return {"FG": 1.0, "RM": None, "BOP": None, "drift_rm": None, "drift_bop": None, "flag": False}
        rm, bp = row["RM"] / fg, row["BOP"] / fg
        d_rm, d_bp = rm / tgt["RM"] - 1, bp / tgt["BOP"] - 1
        return {"FG": 1.0, "RM": round(rm, 2), "BOP": round(bp, 2), "drift_rm": round(d_rm, 3),
                "drift_bop": round(d_bp, 3), "flag": bool(max(d_rm, d_bp) > tol)}

    total = ratio(fam.sum())
    families = [{"family": f, **ratio(r)} for f, r in fam.iterrows()]

    # obsolescence / excess risk per SKU (FR-4.2): age, remaining program life, volatility trend
    sk = skus.set_index("sku_id")
    vi = sku_metrics.set_index("sku_id")["vi"]
    obs = []
    # SKU-level age: FG age, plus avg age of the RM/BOP it consumes
    age_by_item = inv.set_index("item_id")["age_days"]
    for s in sk.index:
        its = bom[bom["sku_id"] == s]["item_id"]
        ages = [age_by_item.get(i, 0.0) for i in its] + [age_by_item.get(s, 0.0)]
        age = float(np.mean(ages)) if ages else 0.0
        remaining_m = max(0.0, (pd.to_datetime(sk.loc[s, "program_end"]).date() - as_of).days / 30.0)
        score = 0.4 * min(age / 180, 1) + 0.3 * (1 - min(remaining_m / 24, 1)) + 0.3 * float(vi.get(s, 0.3))
        obs.append({"sku_id": s, "age_days": round(age, 1), "program_months_left": round(remaining_m, 1),
                    "volatility_index": round(float(vi.get(s, 0.3)), 3), "risk_score": round(score, 3)})
    obs.sort(key=lambda d: -d["risk_score"])

    # FG excess/shortage from reconciled demand: cover beyond 3 weeks is excess
    fg = inv[inv["item_type"] == "FG"].set_index("item_id")
    d4 = recon.groupby("sku_id")["reconciled"].apply(lambda s: s.head(4).mean())
    fg_ex = 0.0
    for s, r in fg.iterrows():
        ex = max(0.0, r["on_hand"] + r["in_transit"] - 3 * d4.get(s, 0.0))
        fg_ex += ex * cost.get(s, 0)
    excess_val = float(item_state["excess_value"].sum()) + fg_ex
    short_val = float(item_state["short_value"].sum())
    wc = {"excess_value": excess_val, "shortage_exposure_value": short_val,
          "expedite_premium_exposure": short_val * cfg["expedite_premium"],
          "penalty_exposure": short_val * (cfg["shortage_penalty_factor"] - 1),
          "carrying_cost_annual": excess_val * cfg["holding_rate"]}
    return {"ratio": total, "families": families, "obsolescence": obs[:25], "working_capital": wc}

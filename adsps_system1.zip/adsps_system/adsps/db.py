"""Operational data store (SQLite for portability; schema is PostgreSQL-friendly).
ForecastVersion is append-only: UPDATE/DELETE are blocked by triggers (SDD 3.1)."""
import datetime as dt
import json
import sqlite3
import threading

import pandas as pd

SCHEMA = """
CREATE TABLE IF NOT EXISTS oem(oem_id TEXT PRIMARY KEY, name TEXT);
CREATE TABLE IF NOT EXISTS plant(plant_id TEXT PRIMARY KEY, oem_id TEXT, name TEXT, weekly_capacity REAL);
CREATE TABLE IF NOT EXISTS sku(sku_id TEXT PRIMARY KEY, description TEXT, oem_id TEXT, plant_id TEXT,
    family TEXT, program_end TEXT, unit_cost REAL);
CREATE TABLE IF NOT EXISTS variant_map(oem_id TEXT, variant_code TEXT, sku_id TEXT, description TEXT,
    PRIMARY KEY(oem_id, variant_code));
CREATE TABLE IF NOT EXISTS item(item_id TEXT PRIMARY KEY, description TEXT, item_type TEXT, unit_cost REAL);
CREATE TABLE IF NOT EXISTS bom_item(item_id TEXT, sku_id TEXT, qty_per_unit REAL, PRIMARY KEY(item_id, sku_id));
CREATE TABLE IF NOT EXISTS supplier(supplier_id TEXT, item_id TEXT, name TEXT, lead_time_days INTEGER, moq REAL,
    PRIMARY KEY(supplier_id, item_id));
CREATE TABLE IF NOT EXISTS inventory_position(item_id TEXT, item_type TEXT, on_hand REAL, in_transit REAL,
    age_days REAL, snapshot_date TEXT, PRIMARY KEY(item_id, snapshot_date));
CREATE TABLE IF NOT EXISTS open_po(po_id TEXT PRIMARY KEY, item_id TEXT, supplier_id TEXT, qty REAL,
    due_date TEXT, status TEXT DEFAULT 'OPEN');
CREATE TABLE IF NOT EXISTS forecast_version(forecast_id INTEGER PRIMARY KEY AUTOINCREMENT, oem_id TEXT,
    plant_id TEXT, sku_id TEXT, variant_code TEXT, horizon_type TEXT, forecast_date TEXT, effective_period TEXT,
    quantity REAL, source_file_ref TEXT, ingested_at TEXT, entry_type TEXT DEFAULT 'ingest');
CREATE INDEX IF NOT EXISTS ix_fv ON forecast_version(sku_id, effective_period, horizon_type);
CREATE TRIGGER IF NOT EXISTS fv_no_update BEFORE UPDATE ON forecast_version
  BEGIN SELECT RAISE(ABORT, 'forecast_version is append-only'); END;
CREATE TRIGGER IF NOT EXISTS fv_no_delete BEFORE DELETE ON forecast_version
  BEGIN SELECT RAISE(ABORT, 'forecast_version is append-only'); END;
CREATE TABLE IF NOT EXISTS actual(sku_id TEXT, period TEXT, quantity REAL, PRIMARY KEY(sku_id, period));
CREATE TABLE IF NOT EXISTS quarantine(id INTEGER PRIMARY KEY AUTOINCREMENT, source_file_ref TEXT,
    record_json TEXT, reason TEXT, ingested_at TEXT);
CREATE TABLE IF NOT EXISTS reconciled_plan(sku_id TEXT, period TEXT, reconciled REAL, sigma REAL, lo REAL,
    hi REAL, rule_qty REAL, ml_qty REAL, ml_weight REAL, ml_note TEXT, PRIMARY KEY(sku_id, period));
CREATE TABLE IF NOT EXISTS sku_metrics(sku_id TEXT PRIMARY KEY, vi REAL, volume REAL, mix REAL, swing REAL,
    bullwhip REAL, abc_class TEXT);
CREATE TABLE IF NOT EXISTS transition_metrics(sku_id TEXT, transition TEXT, mape REAL, bias REAL, n INTEGER,
    PRIMARY KEY(sku_id, transition));
CREATE TABLE IF NOT EXISTS item_state(item_id TEXT PRIMARY KEY, supplier_id TEXT, weekly_demand REAL,
    demand_lt REAL, sigma_lt REAL, safety_stock REAL, rop REAL, position REAL, eoq REAL, excess_units REAL,
    short_units REAL, excess_value REAL, short_value REAL, weeks_cover REAL, vi REAL, abc_class TEXT);
CREATE TABLE IF NOT EXISTS recommendation(rec_id INTEGER PRIMARY KEY AUTOINCREMENT, item_id TEXT, run_date TEXT,
    action TEXT, recommended_qty REAL, recommended_date TEXT, risk_posture TEXT, status TEXT DEFAULT 'DRAFT',
    final_qty REAL, decision_reason TEXT, decided_by TEXT, decided_at TEXT, explain_json TEXT, alt_json TEXT);
CREATE TABLE IF NOT EXISTS po_conflict(id INTEGER PRIMARY KEY AUTOINCREMENT, run_date TEXT, po_id TEXT,
    item_id TEXT, conflict_type TEXT, suggestion TEXT, qty_affected REAL);
CREATE TABLE IF NOT EXISTS po_draft(draft_id INTEGER PRIMARY KEY AUTOINCREMENT, rec_id INTEGER, item_id TEXT,
    supplier_id TEXT, qty REAL, due_date TEXT, created_at TEXT, exported INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS alert(alert_id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, sku_id TEXT, item_id TEXT,
    period TEXT, severity TEXT, owner TEXT, status TEXT DEFAULT 'open', detail TEXT, created_at TEXT,
    sla_due TEXT, resolved_at TEXT, resolution TEXT, resolved_by TEXT);
CREATE TABLE IF NOT EXISTS outbox(msg_id INTEGER PRIMARY KEY AUTOINCREMENT, supplier_id TEXT, channel TEXT,
    payload TEXT, status TEXT DEFAULT 'SENT', commitment TEXT DEFAULT 'PENDING', commit_qty REAL,
    commit_date TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS tier2_snapshot(supplier_id TEXT, item_id TEXT, period TEXT, qty REAL,
    PRIMARY KEY(supplier_id, item_id, period));
CREATE TABLE IF NOT EXISTS ml_model(oem_id TEXT PRIMARY KEY, trained_at TEXT, model_type TEXT, n_rows INTEGER,
    mape_raw REAL, mape_baseline REAL, mape_model REAL, approved INTEGER, blob BLOB);
CREATE TABLE IF NOT EXISTS kpi_snapshot(id INTEGER PRIMARY KEY AUTOINCREMENT, as_of TEXT, payload TEXT);
CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, actor TEXT, action TEXT,
    entity TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS config(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS users(user_id TEXT PRIMARY KEY, role TEXT, supplier_id TEXT, key_hash TEXT);
"""


def utcnow():
    return dt.datetime.now(dt.timezone.utc).replace(tzinfo=None).isoformat(timespec="seconds")


class DB:
    def __init__(self, path=":memory:"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.conn.executescript(SCHEMA)

    def execute(self, sql, params=()):
        with self.lock:
            cur = self.conn.execute(sql, params)
            self.conn.commit()
            return cur

    def executemany(self, sql, rows):
        with self.lock:
            self.conn.executemany(sql, rows)
            self.conn.commit()

    def query(self, sql, params=()):
        with self.lock:
            return [dict(r) for r in self.conn.execute(sql, params).fetchall()]

    def df(self, sql, params=()):
        with self.lock:
            return pd.read_sql_query(sql, self.conn, params=params)

    def replace_table(self, table, df):
        """Replace the contents of a derived (non-immutable) table with a DataFrame."""
        with self.lock:
            self.conn.execute(f"DELETE FROM {table}")
            if len(df):
                cols = list(df.columns)
                self.conn.executemany(
                    f"INSERT INTO {table}({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
                    df.astype(object).where(df.notna(), None).values.tolist())
            self.conn.commit()

    def audit(self, actor, action, entity, detail=None):
        self.execute("INSERT INTO audit_log(ts,actor,action,entity,detail) VALUES(?,?,?,?,?)",
                     (utcnow(), actor, action, entity, json.dumps(detail, default=str)))

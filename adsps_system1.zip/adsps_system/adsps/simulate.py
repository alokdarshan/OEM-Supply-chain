"""Synthetic Tier-1 world: master data, 78 weeks of multi-horizon OEM forecasts + actuals, ERP snapshot, open POs.
Gives the system realistic volatility (festival spikes, mix shifts, OEM-specific bias) for demos and tests."""
import datetime as dt

import numpy as np

from .api import add_user
from .ingestion import ingest_records, week_start

LEAD_WEEKS = {"ABP": 26, "QRF": 10, "MFU": 4, "WDPA": 1}
SD = {"ABP": 0.22, "QRF": 0.14, "MFU": 0.08, "WDPA": 0.04}
OEM_BIAS = {"OEM_A": {"ABP": 0.12, "QRF": 0.06, "MFU": 0.02, "WDPA": 0.0},        # over-forecasts early, corrects down
            "OEM_B": {"ABP": -0.03, "QRF": -0.02, "MFU": -0.01, "WDPA": 0.0}}
FEST_BIAS = {"OEM_B": {"ABP": -0.15, "QRF": -0.12, "MFU": -0.10, "WDPA": -0.02}}   # under-forecasts festival months


def seed(sy, n_sku=60, history_weeks=78, future_weeks=27, as_of=None, seed_=11):
    rng = np.random.default_rng(seed_)
    db = sy.db
    as_of = as_of or dt.date.today()
    cur = week_start(as_of)
    db.executemany("INSERT OR REPLACE INTO oem VALUES(?,?)", [("OEM_A", "OEM Alpha"), ("OEM_B", "OEM Beta")])
    plants = [("P1", "OEM_A"), ("P2", "OEM_A"), ("P3", "OEM_B")]
    db.executemany("INSERT OR REPLACE INTO plant VALUES(?,?,?,?)", [(p, o, f"Plant {p}", 60000) for p, o in plants])

    n_rm, n_bop = max(10, n_sku // 2), max(8, n_sku // 3)
    items = []
    for i in range(n_rm):
        items.append((f"RM{i:03d}", f"Raw material {i}", "RM", float(rng.uniform(40, 400))))
    for i in range(n_bop):
        items.append((f"BOP{i:03d}", f"Bought-out part {i}", "BOP", float(rng.uniform(25, 250))))
    db.executemany("INSERT OR REPLACE INTO item VALUES(?,?,?,?)", items)
    icost = {i[0]: i[3] for i in items}
    sup_rows = []
    for k, (iid, _, typ, _) in enumerate(items):
        lt = int(rng.integers(14, 46) if typ == "RM" else rng.integers(7, 61))
        sup_rows.append((f"SUP{k % 15:02d}", iid, f"Supplier {k % 15}", lt, float(rng.choice([50, 100, 250, 500]))))
    db.executemany("INSERT OR REPLACE INTO supplier VALUES(?,?,?,?,?)", sup_rows)

    skus, base, bom = [], {}, []
    for s in range(n_sku):
        sid, (plant, oem) = f"SKU{s:03d}", plants[s % 3]
        rms = rng.choice(n_rm, 2, replace=False)
        bops = rng.choice(n_bop, int(rng.integers(1, 3)), replace=False)
        mat = 0.0
        for r in rms:
            q = float(rng.uniform(0.2, 2.0)); bom.append((f"RM{r:03d}", sid, q)); mat += q * icost[f"RM{r:03d}"]
        for b in bops:
            q = float(rng.integers(1, 4)); bom.append((f"BOP{b:03d}", sid, q)); mat += q * icost[f"BOP{b:03d}"]
        cost = mat / float(rng.uniform(0.5, 0.8))                  # RM = 50-80% of FG cost
        end = cur + dt.timedelta(days=int(rng.integers(150, 1800)))
        skus.append((sid, f"Component {s}", oem, plant, f"FAM{s % 6}", end.isoformat(), cost))
        base[sid] = float(rng.lognormal(6.3, 0.6))                 # ~ 550 units/week median
    db.executemany("INSERT OR REPLACE INTO sku VALUES(?,?,?,?,?,?,?)", skus)
    db.executemany("INSERT OR REPLACE INTO bom_item VALUES(?,?,?)", bom)
    db.executemany("INSERT OR REPLACE INTO variant_map VALUES(?,?,?,?)",
                   [(s[2], f"{s[2]}-VAR-{s[0][3:]}", s[0], s[1]) for s in skus])
    sku_oem = {s[0]: s[2] for s in skus}
    sku_plant = {s[0]: s[3] for s in skus}

    # ---- true demand (hidden truth) incl. seasonality, noise, mix shifts ----
    all_weeks = [cur + dt.timedelta(weeks=i) for i in range(-history_weeks, future_weeks)]
    truth = {}
    for sid in base:
        series = []
        for k, p in enumerate(all_weeks):
            season = 1.0 + (0.25 if p.month in (9, 10, 11) else 0.10 if p.month == 3 else 0.0)
            series.append(base[sid] * season * (1 + 0.002 * k) * float(np.exp(rng.normal(0, 0.08))))
        truth[sid] = np.array(series)
    for plant, _ in plants:                                          # random mix shifts between SKU pairs
        members = [s for s in base if sku_plant[s] == plant]
        for _ in range(8):
            a, b = rng.choice(members, 2, replace=False)
            k0 = int(rng.integers(0, len(all_weeks) - 4)); amt = float(rng.uniform(0.10, 0.25))
            for k in range(k0, min(k0 + 4, len(all_weeks))):
                moved = truth[a][k] * amt
                truth[a][k] -= moved; truth[b][k] += moved

    recs, acts = [], []
    for sid, ser in truth.items():
        oem = sku_oem[sid]
        for k, p in enumerate(all_weeks):
            if p < cur:
                acts.append((sid, p.isoformat(), float(ser[k])))
            for h, lw in LEAD_WEEKS.items():
                fd = p - dt.timedelta(weeks=lw)
                if fd > cur:
                    continue                                          # not issued yet
                fest = p.month in (3, 9, 10, 11)
                bias = OEM_BIAS[oem][h] + (FEST_BIAS.get(oem, {}).get(h, 0.0) if fest else 0.0)
                q = ser[k] * float(np.exp(bias + rng.normal(0, SD[h])))
                recs.append({"oem_id": oem, "variant_code": f"{oem}-VAR-{sid[3:]}", "horizon_type": h,
                             "forecast_date": fd, "effective_period": p, "quantity": round(max(q, 0), 1),
                             "ingested_at": f"{fd.isoformat()}T06:00:00"})
    db.executemany("INSERT OR REPLACE INTO actual VALUES(?,?,?)", acts)
    for i in range(0, len(recs), 20000):
        ingest_records(db, recs[i:i + 20000], "seed-simulation", "simulator")   # no bus: no alerts on history

    # ---- ERP snapshot: inventory + open POs ----
    wk_req = {}
    for iid, sid, q in bom:
        wk_req[iid] = wk_req.get(iid, 0) + q * base[sid]
    inv, pos = [], []
    for iid, _, typ, _ in items:
        cover = float(rng.choice([1.5, 3, 5, 8, 14], p=[0.1, 0.25, 0.3, 0.2, 0.15]))
        oh = wk_req.get(iid, 100.0) * cover
        inv.append((iid, typ, oh * 0.85, oh * 0.15, float(rng.integers(5, 220)), cur.isoformat()))
        for n in range(int(rng.integers(0, 3))):
            pos.append((f"PO-{iid}-{n}", iid,
                        [x[0] for x in sup_rows if x[1] == iid][0],
                        wk_req.get(iid, 100.0) * float(rng.uniform(1, 5)),
                        (cur + dt.timedelta(weeks=int(rng.integers(1, 9)))).isoformat()))
    for s in skus:
        inv.append((s[0], "FG", base[s[0]] * float(rng.uniform(0.3, 2.5)), 0.0, float(rng.integers(3, 90)), cur.isoformat()))
    db.executemany("INSERT OR REPLACE INTO inventory_position VALUES(?,?,?,?,?,?)", inv)
    db.executemany("INSERT OR REPLACE INTO open_po(po_id,item_id,supplier_id,qty,due_date) VALUES(?,?,?,?,?)", pos)

    # ---- demo users (API keys) ----
    for uid, role, key, sup in [("admin", "admin", "admin-key", None), ("planner1", "demand_planner", "planner-key", None),
                                ("buyer1", "procurement", "buyer-key", None), ("plant1", "plant_manager", "plant-key", None),
                                ("ceo", "executive", "exec-key", None), ("sup00", "tier2", "supplier-key", "SUP00")]:
        add_user(db, uid, role, key, sup)
    return {"truth": truth, "as_of": cur, "skus": [s[0] for s in skus], "hist": history_weeks}


def shock_records(world, n_up=3, n_down=2, seed_=5):
    """A near-term OEM WDPA revision: a few spikes and drops (what the 'line monitor' used to catch)."""
    rng = np.random.default_rng(seed_)
    cur = world["as_of"]
    chosen = list(rng.choice(world["skus"], n_up + n_down, replace=False))
    out = []
    for i, sid in enumerate(chosen):
        f = 1.35 if i < n_up else 0.70
        oem = "OEM_A" if sid in world["skus"] and int(sid[3:]) % 3 < 2 else "OEM_B"
        for w in (0, 1):
            p = cur + dt.timedelta(weeks=w)
            base_q = float(world["truth"][sid][world["hist"] + w])
            out.append({"oem_id": oem, "variant_code": f"{oem}-VAR-{sid[3:]}", "horizon_type": "WDPA",
                        "forecast_date": cur, "effective_period": p, "quantity": round(base_q * f, 1)})
    return out

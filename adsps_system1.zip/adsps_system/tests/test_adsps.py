import datetime as dt
import sqlite3

import numpy as np
import pytest
from fastapi.testclient import TestClient

from adsps import alerts as al, procurement, reconciliation
from adsps.api import create_app
from adsps.config import DEFAULTS
from adsps.platform import ADSPS
from adsps.simulate import seed, shock_records


@pytest.fixture(scope="module")
def world():
    sy = ADSPS()
    w = seed(sy, n_sku=30, as_of=dt.date(2026, 10, 6))
    sy.run_cycle(w["as_of"])
    return sy, w


def test_forecast_versions_are_append_only(world):
    sy, _ = world
    with pytest.raises(sqlite3.DatabaseError):
        sy.db.execute("UPDATE forecast_version SET quantity=0 WHERE forecast_id=1")
    with pytest.raises(sqlite3.DatabaseError):
        sy.db.execute("DELETE FROM forecast_version WHERE forecast_id=1")


def test_ingestion_quarantines_bad_rows_without_blocking(world):
    sy, w = world
    good = {"oem_id": "OEM_A", "variant_code": "OEM_A-VAR-000", "horizon_type": "MFU",
            "forecast_date": "2026-10-06", "effective_period": "2026-11-03", "quantity": 100}
    bad = [dict(good, quantity=-5), dict(good, variant_code="NOPE"), dict(good, horizon_type="XYZ")]
    r = sy.ingest([good] + bad, "test.csv")
    assert r["accepted"] == 1 and r["quarantined"] == 3


def test_reconciliation_weights_shift_to_recent_signal():
    cfg = DEFAULTS
    lead = np.array([300, 120, 50, 3])
    W = reconciliation.horizon_weight_matrix(lead, cfg)
    assert np.allclose(W.sum(1), 1.0)
    assert W[0].argmax() == 0 and W[3].argmax() == 3          # ABP far out, WDPA inside lead window


def test_safety_stock_formula():
    z = procurement.z_for(0.95)
    assert abs(z - 1.645) < 0.01
    assert procurement._round_lot(101, 50) == 150


def test_volatility_and_plan_outputs(world):
    sy, _ = world
    m = sy.db.df("SELECT * FROM sku_metrics")
    assert m["vi"].between(0, 1).all() and len(m) == 30
    plan = sy.db.df("SELECT * FROM reconciled_plan")
    assert (plan["hi"] >= plan["lo"]).all() and (plan["reconciled"] > 0).all()


def test_ml_gate_and_recommendations_are_drafts(world):
    sy, _ = world
    for m in sy.db.query("SELECT * FROM ml_model"):
        if m["approved"]:
            assert m["mape_model"] <= min(m["mape_raw"], m["mape_baseline"]) * 0.95 + 1e-9
    assert {r["status"] for r in sy.db.query("SELECT status FROM recommendation")} <= {"DRAFT", "SUPERSEDED"}


def test_shock_raises_deduped_alerts_with_sla(world):
    sy, w = world
    r = sy.ingest(shock_records(w), "oem_wdpa.csv")
    assert r["alerts_raised"] > 0
    types = {a["type"] for a in al.list_alerts(sy.db)}
    assert {"demand-spike", "demand-drop"} & types
    again = sy.ingest(shock_records(w), "oem_wdpa.csv")        # identical batch must not duplicate open alerts
    assert again["alerts_raised"] == 0
    a = al.list_alerts(sy.db)[0]
    assert a["sla_due"] > a["created_at"]


def test_override_requires_reason_and_creates_po_draft(world):
    sy, _ = world
    rec = sy.db.query("SELECT rec_id FROM recommendation WHERE status='DRAFT' AND recommended_qty>0 LIMIT 2")
    with pytest.raises(ValueError):
        procurement.decide(sy.db, rec[0]["rec_id"], "override", "buyer1")
    out = procurement.decide(sy.db, rec[0]["rec_id"], "override", "buyer1", "supplier strike risk", 123)
    assert out["status"] == "OVERRIDDEN"
    assert sy.db.query("SELECT COUNT(*) c FROM po_draft")[0]["c"] >= 1


def test_api_rbac_and_tier2_scoping(world):
    sy, _ = world
    c = TestClient(create_app(sy))
    assert c.get("/api/v1/alerts").status_code == 401
    assert c.get("/api/v1/dashboards/executive-summary", headers={"X-API-Key": "planner-key"}).status_code == 403
    assert c.get("/api/v1/dashboards/executive-summary", headers={"X-API-Key": "exec-key"}).status_code == 200
    assert c.get("/api/v1/skus/SKU000/volatility", headers={"X-API-Key": "planner-key"}).status_code == 200
    mine = c.get("/api/v1/tier2/requirements", headers={"X-API-Key": "supplier-key"}).json()
    assert all(m["supplier_id"] == "SUP00" for m in mine)

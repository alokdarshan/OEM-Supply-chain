"""End-to-end demo:  python run_demo.py [--skus 60] [--serve]"""
import argparse
import datetime as dt
import json

from adsps import alerts as al, procurement
from adsps.platform import ADSPS, export_report
from adsps.simulate import seed, shock_records


def money(x):
    return f"Rs {x/1e5:,.1f} L"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skus", type=int, default=60)
    ap.add_argument("--db", default=":memory:")
    ap.add_argument("--serve", action="store_true", help="start the REST API + web console on :8000")
    a = ap.parse_args()

    sy = ADSPS(a.db)
    print("Seeding synthetic OEM forecasts, actuals, ERP snapshot ...")
    world = seed(sy, n_sku=a.skus, as_of=dt.date.today())
    as_of = world["as_of"]
    n = sy.db.query("SELECT COUNT(*) c FROM forecast_version")[0]["c"]
    print(f"  {n:,} immutable forecast versions, {a.skus} SKUs")

    print("\n[1] Planning cycle on baseline data ...")
    s = sy.run_cycle(as_of)
    show(s)

    print("\n[2] OEM sends a volatile WDPA revision (3 spikes, 2 drops) ...")
    r = sy.ingest(shock_records(world), source="oem_wdpa_today.csv", actor="planner1")
    print(f"  ingested={r['accepted']} quarantined={r['quarantined']} alerts raised={r['alerts_raised']}")
    for x in [a_ for a_ in al.list_alerts(sy.db) if a_['type'] != 'PO-conflict'][:6]:
        d = json.loads(x["detail"])
        print(f"   - [{x['severity']:6}] {x['type']:13} {x['sku_id'] or x['item_id']:8} {x['period']} -> {x['owner']}  {d}")
    s = sy.run_cycle(as_of)
    print("\n[3] Re-plan after the revision:")
    show(s)

    print("\n[4] Planner workflow: top ORDER_NOW recommendation")
    top = sy.db.query("""SELECT * FROM recommendation WHERE status='DRAFT' AND action='ORDER_NOW'
                         ORDER BY recommended_qty DESC LIMIT 1""")
    if top:
        t = top[0]; ex = json.loads(t["explain_json"]); alts = json.loads(t["alt_json"])
        print(f"  {t['item_id']}: order {t['recommended_qty']:.0f} by {t['recommended_date']} ({t['risk_posture']})")
        print(f"  why: demand over lead time={ex['demand_during_lt']:.0f}, sigma_LT={ex['sigma_lt']:.0f}, "
              f"VI={ex['volatility_index']:.2f}, SS={ex['safety_stock']:.0f}, position={ex['position']:.0f}")
        for k, v in alts.items():
            print(f"    {k:12} SL={v['service_level']:.3f} SS={v['safety_stock']:.0f} order={v['order_qty']:.0f} "
                  f"exp.shortage={v['expected_shortage_units']:.1f} exp.excess value={money(v['expected_excess_value'])}")
        print("  ->", procurement.decide(sy.db, t["rec_id"], "accept", "buyer1"))
    p = export_report(sy.db, "adsps_report.xlsx")
    print(f"\nExcel report written: {p}")

    if a.serve:
        import uvicorn
        from adsps.api import create_app
        print("\nAPI + console on http://localhost:8000   keys: admin-key planner-key buyer-key plant-key exec-key supplier-key")
        uvicorn.run(create_app(sy), host="0.0.0.0", port=8000)


def show(s):
    wc, so, v, rc = s["working_capital"], s["stock_out_risk"], s["volatility"], s["recommendations"]
    print(f"  excess inventory {money(wc['excess_value'])} | shortage exposure {money(wc['shortage_exposure_value'])} "
          f"| expedite premium {money(wc['expedite_premium_exposure'])}")
    print(f"  items at stock-out risk {so['items_at_risk']} | mean volatility idx {v['mean_vi']:.2f} | "
          f"mean bullwhip {v['mean_bullwhip']:.2f}x | FG:RM:BOP = 1:{s['inventory_ratio'].get('RM')}:{s['inventory_ratio'].get('BOP')}")
    print(f"  ORDER_NOW {rc['order_now']} | planned {rc['planned']} | PO conflicts {rc['po_conflicts']} | open alerts {s['open_alerts']}")
    for m in s["ml_models"]:
        print(f"  ML {m['oem_id']}: {m['model_type']} MAPE raw={m['mape_raw']:.3f} baseline={m['mape_baseline']:.3f} "
              f"model={m['mape_model']:.3f} approved={bool(m['approved'])}" if m["mape_raw"] else f"  ML {m['oem_id']}: insufficient history")


if __name__ == "__main__":
    main()

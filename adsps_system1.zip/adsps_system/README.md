# ADSPS - Adaptive Demand & Supply Planning System (Python)

Implements the SRS v1.0 / SDD v1.0 + rev1 (ML demand sensing) for Tier-1 automotive suppliers.

## Quick start
```bash
pip install -r requirements.txt
python run_demo.py            # seeds synthetic data, runs the full cycle, shows alerts + planner workflow
python run_demo.py --serve    # then open http://localhost:8000  (API keys below)
python -m pytest -q tests
```
Demo API keys: `admin-key`, `planner-key`, `buyer-key`, `plant-key`, `exec-key`, `supplier-key` (Tier-2, scoped to SUP00).
Interactive API docs: `/docs`. Use a file DB for persistence: `python run_demo.py --db adsps.db`.

## Module map (SDD -> code)
| SDD | File | What it does |
|---|---|---|
| 3.1 Ingestion | `ingestion.py`, `db.py` | Validate, map OEM variant -> SKU, quarantine bad rows, append-only `forecast_version` (DB triggers block UPDATE/DELETE); manual corrections append a new version + audit |
| 3.2 Reconciliation | `reconciliation.py` | Horizon-weighted blend (ABP->WDPA as period nears), volatility-driven uncertainty band |
| 3.3 ML sensing | `ml_sensing.py` | One gradient-boosting model per OEM predicts actual/forecast ratio; EWMA bias baseline; used only if it beats best non-ML baseline on held-out data; monthly + drift retrain; trust-weighted blend; explainability note |
| 3.4 Volatility | `volatility.py` | MAPE/bias per horizon transition, Volatility Index (volume, mix shift, WoW swing), bullwhip ratio, ABC class, MOQ lot-sizing amplification helper |
| 3.5 Procurement | `procurement.py` | Dynamic SS = Z x sigma_LT, ROP, EOQ, MOQ rounding, conservative/balanced/aggressive postures with stock-out vs excess trade-off, open-PO reconciliation (EXCESS / LATE_SHORTAGE), accept/override (reason mandatory) -> PO *draft* |
| 3.6 Inventory | `inventory.py` | FG:RM:BOP ratio drift vs 1:3:2, obsolescence score, Rs excess/shortage/expedite exposure |
| 3.7 Alerts | `alerts.py` | Spike/drop, mix-shift, capacity-risk, PO-conflict; dedupe, owner routing, SLA timers, resolution log |
| 3.8 Tier-2 | `tier2.py` | Requirement-delta sharing via outbox gateway, commitment capture, ERP file connector |
| 3.9/5 Dashboards/API | `platform.py`, `api.py`, `ui.html` | Orchestrator, executive KPIs, REST + RBAC, minimal web console, Excel export |
| 3.10 Admin | `config.py` | All thresholds/weights editable at runtime via `PUT /api/v1/admin/config` |
| - | `simulate.py` | Synthetic OEMs, forecasts at four horizons, actuals, ERP snapshot, shocks |

## Production notes / known simplifications
- SQLite stands in for PostgreSQL + a columnar warehouse; SQL is portable. In-process `EventBus` stands in for Kafka.
- `OutboxGateway` and `ERPConnector` are stubs (persist/CSV) - swap in SMTP/EDI/SAP adapters behind the same methods.
- Auth is API-key based; replace with SSO/JWT. PDF export not included (Excel only).
- Recommendations are always drafts (Phase 1 constraint); nothing writes POs to ERP.
- Timing: steady-state planning cycle ~8 s per 600 SKUs (~35 s est. for 2,500); ML training is a monthly job and dominates the first run.
- The bullwhip metric compares realised-demand CV to ABP CV; values < 1 simply mean the OEM annual plan was noisier than reality.
